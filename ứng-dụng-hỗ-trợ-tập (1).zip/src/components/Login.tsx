import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Lock, User, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

interface LoginProps {
  onLogin: (username: string) => void;
}

export function Login({ onLogin }: LoginProps) {
  const [username, setUsername] = useState(() => {
    const remembered = localStorage.getItem('eduai_remembered');
    return remembered ? JSON.parse(remembered).username : '';
  });
  const [password, setPassword] = useState(() => {
    const remembered = localStorage.getItem('eduai_remembered');
    return remembered ? JSON.parse(remembered).password : '';
  });
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isRegister, setIsRegister] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [rememberMe, setRememberMe] = useState(() => {
    return localStorage.getItem('eduai_remembered') !== null;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate auth logic
    setTimeout(() => {
      if (isRegister) {
        // Register logic
        if (password !== confirmPassword) {
          toast.error('Mật khẩu xác nhận không khớp!');
          setIsLoading(false);
          return;
        }
        localStorage.setItem('eduai_auth', JSON.stringify({ username, password }));
        toast.success('Đăng ký thành công! Hãy đăng nhập bằng tài khoản mới.');
        setIsRegister(false);
        setPassword('');
        setConfirmPassword('');
      } else {
        // Login logic
        const savedAuth = localStorage.getItem('eduai_auth');
        const auth = savedAuth ? JSON.parse(savedAuth) : { username: 'User', password: '123' };

        if (username === auth.username && password === auth.password) {
          if (rememberMe) {
            localStorage.setItem('eduai_remembered', JSON.stringify({ username, password }));
          } else {
            localStorage.removeItem('eduai_remembered');
          }
          localStorage.setItem('eduai_session', JSON.stringify({ username, loggedIn: true }));
          onLogin(username);
          toast.success(`Chào mừng quay trở lại, ${username}!`);
        } else {
          toast.error('Sai tên đăng nhập hoặc mật khẩu!');
        }
      }
      setIsLoading(false);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-50/80 backdrop-blur-md p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        className="w-full max-w-md bg-white rounded-[3rem] shadow-2xl border border-slate-100 overflow-hidden"
      >
        <div className="p-10 space-y-8">
          <div className="text-center space-y-4">
            <div className="inline-flex p-4 bg-brand-50 text-brand-600 rounded-3xl">
              <ShieldCheck size={40} />
            </div>
            <h2 className="text-3xl font-display font-bold text-slate-800">
              {isRegister ? 'Tạo tài khoản EduAI' : 'Đăng nhập EduAI'}
            </h2>
            <p className="text-slate-500">Người bạn đồng hành Socratic của bạn</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input 
                  type="text"
                  placeholder="Tên đăng nhập"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-12 pr-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 outline-none transition-all"
                  required
                />
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input 
                  type="password"
                  placeholder="Mật khẩu"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-12 pr-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 outline-none transition-all"
                  required
                />
              </div>
              {isRegister && (
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                  <input 
                    type="password"
                    placeholder="Xác nhận mật khẩu"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full pl-12 pr-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 outline-none transition-all"
                    required
                  />
                </div>
              )}
            </div>

            {!isRegister && (
              <div className="flex items-center gap-2 px-2">
                <input 
                  type="checkbox" 
                  id="remember" 
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-300 text-brand-500 focus:ring-brand-500"
                />
                <label htmlFor="remember" className="text-sm text-slate-500 cursor-pointer select-none">
                  Ghi nhớ đăng nhập
                </label>
              </div>
            )}

            <button 
              type="submit"
              disabled={isLoading}
              className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 hover:bg-slate-800 transition-all shadow-lg shadow-slate-200 disabled:opacity-50"
            >
              {isLoading ? (
                <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  {isRegister ? 'Đăng ký ngay' : 'Bắt đầu học tập'}
                  <ArrowRight size={20} />
                </>
              )}
            </button>
          </form>

          <div className="space-y-4">
            <button 
              onClick={() => {
                setIsRegister(!isRegister);
                setConfirmPassword('');
              }}
              className="w-full text-brand-600 font-medium hover:underline text-sm"
            >
              {isRegister ? 'Đã có tài khoản? Đăng nhập' : 'Chưa có tài khoản? Đăng ký ngay'}
            </button>

            {!isRegister && (
              <div className="text-center text-sm text-slate-400">
                Mặc định: <span className="font-mono text-slate-600">User / 123</span>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
