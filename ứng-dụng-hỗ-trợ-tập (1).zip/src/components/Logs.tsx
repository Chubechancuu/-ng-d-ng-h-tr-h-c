import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { History, Search, Calendar, MessageSquare, ArrowRight } from 'lucide-react';

interface ChatLog {
  role: 'user' | 'assistant';
  content: string;
  timestamp?: string;
}

const LANGUAGES_DICT: Record<string, any> = {
  "Tiếng Việt": {
    "header": "Nhật ký học tập",
    "desc": "Xem lại toàn bộ lịch sử tương tác của bạn với AI.",
    "search_placeholder": "Tìm kiếm nội dung...",
    "no_logs": "Không tìm thấy lịch sử trò chuyện nào.",
    "table_role": "Vai trò",
    "table_content": "Nội dung",
    "table_action": "Hành động",
    "role_user": "Người dùng",
    "role_ai": "Gia sư AI",
    "details": "Chi tiết"
  },
  "English": {
    "header": "Learning Logs",
    "desc": "Review your entire interaction history with AI.",
    "search_placeholder": "Search content...",
    "no_logs": "No chat history found.",
    "table_role": "Role",
    "table_content": "Content",
    "table_action": "Action",
    "role_user": "User",
    "role_ai": "AI Tutor",
    "details": "Details"
  },
  "Français": {
    "header": "Journaux d'apprentissage",
    "desc": "Consultez l'intégralité de votre historique d'interaction avec l'IA.",
    "search_placeholder": "Rechercher du contenu...",
    "no_logs": "Aucun historique de chat trouvé.",
    "table_role": "Rôle",
    "table_content": "Contenu",
    "table_action": "Action",
    "role_user": "Utilisateur",
    "role_ai": "Tuteur IA",
    "details": "Détails"
  },
  "日本語": {
    "header": "学習ログ",
    "desc": "AIとのすべてのやり取りの履歴を確認します。",
    "search_placeholder": "コンテンツを検索...",
    "no_logs": "チャット履歴が見つかりません。",
    "table_role": "役割",
    "table_content": "内容",
    "table_action": "アクション",
    "role_user": "ユーザー",
    "role_ai": "AIチューター",
    "details": "詳細"
  },
  "Deutsch": {
    "header": "Lernprotokolle",
    "desc": "Überprüfen Sie Ihren gesamten Interaktionsverlauf mit der KI.",
    "search_placeholder": "Inhalt suchen...",
    "no_logs": "Kein Chat-Verlauf gefunden.",
    "table_role": "Rolle",
    "table_content": "Inhalt",
    "table_action": "Aktion",
    "role_user": "Benutzer",
    "role_ai": "KI-Tutor",
    "details": "Details"
  },
  "Español": {
    "header": "Registros de Aprendizaje",
    "desc": "Revisa todo tu historial de interacción con la IA.",
    "search_placeholder": "Buscar contenido...",
    "no_logs": "No se encontró historial de chat.",
    "table_role": "Rol",
    "table_content": "Contenido",
    "table_action": "Acción",
    "role_user": "Usuario",
    "role_ai": "Tutor de IA",
    "details": "Detalles"
  },
  "한국어": {
    "header": "학습 로그",
    "desc": "AI와의 전체 상호작용 기록을 검토하세요.",
    "search_placeholder": "콘텐츠 검색...",
    "no_logs": "채팅 기록을 찾을 수 없습니다.",
    "table_role": "역할",
    "table_content": "내용",
    "table_action": "작업",
    "role_user": "사용자",
    "role_ai": "AI 튜터",
    "details": "상세 정보",
    "tab_chat": "Trò chuyện",
    "tab_history": "Lịch sử học tập",
    "table_date": "Ngày",
    "table_activity": "Hoạt động",
    "table_duration": "Thời lượng",
    "table_result": "Kết quả",
    "table_xp": "XP"
  }
};

export function Logs({ setActiveTab }: { setActiveTab: (tab: string) => void }) {
  const [logs, setLogs] = useState<ChatLog[]>([]);
  const [studyHistory, setStudyHistory] = useState<any[]>([]);
  const [activeSubTab, setActiveSubTab] = useState<'chat' | 'history'>('chat');
  const [searchTerm, setSearchTerm] = useState('');
  const [language, setLanguage] = useState('Tiếng Việt');

  useEffect(() => {
    const savedSettings = localStorage.getItem('eduai_settings');
    if (savedSettings) {
      setLanguage(JSON.parse(savedSettings).language || 'Tiếng Việt');
    }

    const savedLogs = localStorage.getItem('eduai_tutor_chat');
    if (savedLogs) {
      setLogs(JSON.parse(savedLogs));
    }

    const savedHistory = localStorage.getItem('eduai_study_history');
    if (savedHistory) {
      setStudyHistory(JSON.parse(savedHistory));
    }
  }, []);

  const dict = LANGUAGES_DICT[language] || LANGUAGES_DICT['Tiếng Việt'];

  const filteredLogs = logs.filter(log => 
    log.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleGoToTutor = () => {
    setActiveTab('tutor');
  };

  return (
    <div className="max-w-7xl mx-auto space-y-10 py-8 px-4">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div className="space-y-2">
          <h2 className="text-4xl font-display font-bold text-slate-800 flex items-center gap-4">
            <div className="p-3 bg-brand-500 text-white rounded-2xl shadow-lg shadow-brand-200">
              <History size={32} />
            </div>
            {dict.header}
          </h2>
          <p className="text-slate-500 text-xl ml-16">{dict.desc}</p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex bg-slate-100 p-1.5 rounded-2xl">
            <button 
              onClick={() => setActiveSubTab('chat')}
              className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${activeSubTab === 'chat' ? 'bg-white text-brand-500 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              {dict.tab_chat || 'Chat'}
            </button>
            <button 
              onClick={() => setActiveSubTab('history')}
              className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${activeSubTab === 'history' ? 'bg-white text-brand-500 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              {dict.tab_history || 'History'}
            </button>
          </div>

          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-500 transition-colors" size={24} />
            <input 
              type="text"
              placeholder={dict.search_placeholder}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-14 pr-6 py-4 rounded-2xl bg-white/80 backdrop-blur-xl border border-white/20 shadow-xl focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 outline-none transition-all min-w-[300px] text-lg glass-morphism"
            />
          </div>
        </div>
      </header>

      {activeSubTab === 'chat' ? (
        filteredLogs.length === 0 ? (
          <div className="bg-white/80 backdrop-blur-xl p-24 rounded-[3.5rem] border border-white/20 shadow-2xl text-center space-y-6 glass-morphism">
            <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <MessageSquare size={48} className="text-slate-200" />
            </div>
            <p className="text-slate-400 text-xl font-medium">{dict.no_logs}</p>
          </div>
        ) : (
          <div className="bg-white/80 backdrop-blur-xl rounded-[3.5rem] border border-white/20 shadow-2xl overflow-hidden glass-morphism">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/50 border-b border-slate-100/50">
                    <th className="px-10 py-6 text-sm font-bold uppercase tracking-widest text-slate-500">{dict.table_role}</th>
                    <th className="px-10 py-6 text-sm font-bold uppercase tracking-widest text-slate-500">{dict.table_content}</th>
                    <th className="px-10 py-6 text-sm font-bold uppercase tracking-widest text-slate-500">{dict.table_action}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100/50">
                  {filteredLogs.map((log, i) => (
                    <motion.tr 
                      key={i}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className="hover:bg-brand-50/30 transition-colors group"
                    >
                      <td className="px-10 py-8 whitespace-nowrap">
                        <span className={`inline-flex items-center px-4 py-1.5 rounded-xl text-xs font-bold uppercase tracking-widest shadow-sm ${
                          log.role === 'user' ? 'bg-blue-100 text-blue-700' : 'bg-brand-100 text-brand-700'
                        }`}>
                          {log.role === 'user' ? dict.role_user : dict.role_ai}
                        </span>
                      </td>
                      <td className="px-10 py-8">
                        <p className="text-lg text-slate-600 line-clamp-2 max-w-2xl leading-relaxed">
                          {log.content}
                        </p>
                      </td>
                      <td className="px-10 py-8">
                        <button 
                          onClick={handleGoToTutor}
                          className="text-slate-400 hover:text-brand-500 transition-all flex items-center gap-2 text-sm font-bold group-hover:translate-x-1"
                        >
                          {dict.details}
                          <ArrowRight size={18} />
                        </button>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      ) : (
        studyHistory.length === 0 ? (
          <div className="bg-white/80 backdrop-blur-xl p-24 rounded-[3.5rem] border border-white/20 shadow-2xl text-center space-y-6 glass-morphism">
            <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <Calendar size={48} className="text-slate-200" />
            </div>
            <p className="text-slate-400 text-xl font-medium">{language === 'Tiếng Việt' ? 'Lịch sử trống.' : 'History is empty.'}</p>
          </div>
        ) : (
          <div className="bg-white/80 backdrop-blur-xl rounded-[3.5rem] border border-white/20 shadow-2xl overflow-hidden glass-morphism">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/50 border-b border-slate-100/50">
                    <th className="px-10 py-6 text-sm font-bold uppercase tracking-widest text-slate-500">{dict.table_date || 'Date'}</th>
                    <th className="px-10 py-6 text-sm font-bold uppercase tracking-widest text-slate-500">{dict.table_activity || 'Activity'}</th>
                    <th className="px-10 py-6 text-sm font-bold uppercase tracking-widest text-slate-500">{dict.table_duration || 'Duration'}</th>
                    <th className="px-10 py-6 text-sm font-bold uppercase tracking-widest text-slate-500">{dict.table_result || 'Result'}</th>
                    <th className="px-10 py-6 text-sm font-bold uppercase tracking-widest text-slate-500">{dict.table_xp || 'XP'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100/50">
                  {studyHistory.map((item, i) => (
                    <motion.tr 
                      key={i}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className="hover:bg-emerald-50/30 transition-colors group"
                    >
                      <td className="px-10 py-8 whitespace-nowrap text-slate-500 font-medium">
                        {new Date(item.date).toLocaleDateString()}
                      </td>
                      <td className="px-10 py-8 font-bold text-slate-800">
                        {item.activity}
                      </td>
                      <td className="px-10 py-8 text-slate-600">
                        {item.duration} {language === 'Tiếng Việt' ? 'phút' : 'mins'}
                      </td>
                      <td className="px-10 py-8">
                        <span className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-lg text-xs font-bold uppercase tracking-widest">
                          {item.result}
                        </span>
                      </td>
                      <td className="px-10 py-8 font-mono font-bold text-brand-500">
                        +{item.xp}
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      )}
    </div>
  );
}
