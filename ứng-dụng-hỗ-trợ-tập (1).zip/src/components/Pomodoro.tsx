import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, RotateCcw, Coffee, Brain, Bell, Settings as SettingsIcon } from 'lucide-react';
import { toast } from 'sonner';

const LANGUAGES_DICT: Record<string, any> = {
  "Tiếng Việt": {
    "header": "Bộ đếm Pomodoro",
    "desc": "Tập trung cao độ, nghỉ ngơi khoa học.",
    "work": "Tập trung",
    "break": "Nghỉ ngơi",
    "sessions": "Phiên hoàn thành",
    "total_time": "Tổng thời gian",
    "tip_title": "Mẹo nhỏ",
    "tip_desc": "Trong 5 phút nghỉ ngơi, hãy đứng dậy vươn vai hoặc uống một chút nước. Tránh xa màn hình điện thoại để não bộ thực sự được phục hồi.",
    "toast_work_complete": "Tuyệt vời! Bạn đã hoàn thành một phiên tập trung.",
    "toast_work_desc": "Hãy dành 5 phút để nghỉ ngơi nhé.",
    "toast_break_complete": "Hết giờ nghỉ!",
    "toast_break_desc": "Sẵn sàng cho phiên tập trung tiếp theo chưa?"
  },
  "English": {
    "header": "Pomodoro Timer",
    "desc": "Focus deeply, rest scientifically.",
    "work": "Focus",
    "break": "Break",
    "sessions": "Sessions Completed",
    "total_time": "Total Time",
    "tip_title": "Quick Tip",
    "tip_desc": "During your 5-minute break, stand up, stretch, or drink some water. Stay away from screens to let your brain truly recover.",
    "toast_work_complete": "Great job! You've completed a focus session.",
    "toast_work_desc": "Take 5 minutes to rest.",
    "toast_break_complete": "Break's over!",
    "toast_break_desc": "Ready for the next focus session?"
  },
  "Français": {
    "header": "Minuteur Pomodoro",
    "desc": "Concentrez-vous profondément, reposez-vous scientifiquement.",
    "work": "Travail",
    "break": "Pause",
    "sessions": "Sessions terminées",
    "total_time": "Temps total",
    "tip_title": "Petit conseil",
    "tip_desc": "Pendant votre pause de 5 minutes, levez-vous, étirez-vous ou buvez de l'eau. Éloignez-vous des écrans pour laisser votre cerveau récupérer.",
    "toast_work_complete": "Excellent travail ! Vous avez terminé une session de concentration.",
    "toast_work_desc": "Prenez 5 minutes pour vous reposer.",
    "toast_break_complete": "La pause est finie !",
    "toast_break_desc": "Prêt pour la prochaine session ?"
  },
  "日本語": {
    "header": "ポモドーロタイマー",
    "desc": "深く集中し、科学的に休息しましょう。",
    "work": "集中",
    "break": "休憩",
    "sessions": "完了したセッション",
    "total_time": "合計時間",
    "tip_title": "ヒント",
    "tip_desc": "5分間の休憩中は、立ち上がってストレッチをしたり、水を飲んだりしましょう。脳を真に回復させるために、画面から離れてください。",
    "toast_work_complete": "素晴らしい！集中セッションを完了しました。",
    "toast_work_desc": "5分間休憩しましょう。",
    "toast_break_complete": "休憩終了！",
    "toast_break_desc": "次の集中セッションの準備はいいですか？"
  }
};

export function Pomodoro() {
  const [minutes, setMinutes] = useState(25);
  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<'work' | 'break'>('work');
  const [sessions, setSessions] = useState(0);
  const [language, setLanguage] = useState('Tiếng Việt');
  const [pomoWork, setPomoWork] = useState(25);
  const [pomoBreak, setPomoBreak] = useState(5);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const dict = LANGUAGES_DICT[language] || LANGUAGES_DICT['Tiếng Việt'];

  useEffect(() => {
    const savedSettings = localStorage.getItem('eduai_settings');
    if (savedSettings) {
      const parsed = JSON.parse(savedSettings);
      setLanguage(parsed.language || 'Tiếng Việt');
      const workTime = parsed.pomoWork || 25;
      const breakTime = parsed.pomoBreak || 5;
      setPomoWork(workTime);
      setPomoBreak(breakTime);
      setMinutes(workTime);
    }
  }, []);

  useEffect(() => {
    if (isActive) {
      timerRef.current = setInterval(() => {
        if (seconds > 0) {
          setSeconds(seconds - 1);
        } else if (minutes > 0) {
          setMinutes(minutes - 1);
          setSeconds(59);
        } else {
          handleTimerComplete();
        }
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, minutes, seconds]);

  const handleTimerComplete = () => {
    setIsActive(false);
    if (timerRef.current) clearInterval(timerRef.current);
    
    if (mode === 'work') {
      setSessions(s => s + 1);
      toast.success(dict.toast_work_complete, {
        description: dict.toast_work_desc,
        duration: 5000,
      });
      setMode('break');
      setMinutes(pomoBreak);
    } else {
      toast.info(dict.toast_break_complete, {
        description: dict.toast_break_desc,
        duration: 5000,
      });
      setMode('work');
      setMinutes(pomoWork);
    }
    setSeconds(0);
    
    try {
      const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
      audio.play();
    } catch (e) {}
  };

  const toggleTimer = () => setIsActive(!isActive);

  const resetTimer = () => {
    setIsActive(false);
    setMode('work');
    setMinutes(pomoWork);
    setSeconds(0);
  };

  const formatTime = (m: number, s: number) => {
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progress = mode === 'work' 
    ? ((pomoWork * 60 - (minutes * 60 + seconds)) / (pomoWork * 60)) * 100 
    : ((pomoBreak * 60 - (minutes * 60 + seconds)) / (pomoBreak * 60)) * 100;

  return (
    <div className="max-w-4xl mx-auto space-y-12 py-8 px-4">
      <header className="text-center space-y-4">
        <h2 className="text-5xl font-display font-bold text-slate-800">{dict.header}</h2>
        <p className="text-slate-500 text-xl">{dict.desc}</p>
      </header>

      <div className="relative flex flex-col items-center">
        <div className="relative w-80 h-80 md:w-96 md:h-96 flex items-center justify-center">
          <svg className="w-full h-full -rotate-90 drop-shadow-2xl">
            <circle
              cx="50%"
              cy="50%"
              r="48%"
              className="fill-none stroke-slate-100 stroke-[12px]"
            />
            <motion.circle
              cx="50%"
              cy="50%"
              r="48%"
              className={cn(
                "fill-none stroke-[12px] transition-colors duration-500",
                mode === 'work' ? "stroke-brand-500" : "stroke-emerald-500"
              )}
              strokeDasharray="100 100"
              initial={{ strokeDashoffset: 100 }}
              animate={{ strokeDashoffset: 100 - progress }}
              style={{ strokeDasharray: '301.59', strokeDashoffset: `${301.59 * (1 - progress / 100)}` }}
            />
          </svg>
          
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/40 backdrop-blur-xl rounded-full m-6 border border-white/50 shadow-inner glass-morphism">
            <AnimatePresence mode="wait">
              <motion.div
                key={mode}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-2 mb-2"
              >
                {mode === 'work' ? (
                  <Brain className="text-brand-500" size={24} />
                ) : (
                  <Coffee className="text-emerald-500" size={24} />
                )}
                <span className={cn(
                  "text-base font-bold uppercase tracking-widest",
                  mode === 'work' ? "text-brand-600" : "text-emerald-600"
                )}>
                  {mode === 'work' ? dict.work : dict.break}
                </span>
              </motion.div>
            </AnimatePresence>
            <span className="text-7xl md:text-8xl font-mono font-bold text-slate-800 tabular-nums tracking-tighter">
              {formatTime(minutes, seconds)}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-8 mt-16">
          <button 
            onClick={resetTimer}
            className="p-5 rounded-[2rem] bg-white/80 backdrop-blur-md text-slate-600 hover:bg-white border border-white/20 shadow-xl transition-all hover:scale-110 active:scale-95"
            title="Reset"
          >
            <RotateCcw size={32} />
          </button>
          
          <button 
            onClick={toggleTimer}
            className={cn(
              "w-24 h-24 rounded-full flex items-center justify-center shadow-2xl transition-all hover:scale-110 active:scale-95",
              isActive 
                ? "bg-slate-800 text-white shadow-slate-200" 
                : "bg-brand-500 text-white shadow-brand-200"
            )}
          >
            {isActive ? <Pause size={48} fill="currentColor" /> : <Play size={48} className="ml-2" fill="currentColor" />}
          </button>
          
          <button 
            className="p-5 rounded-[2rem] bg-white/80 backdrop-blur-md text-slate-600 hover:bg-white border border-white/20 shadow-xl transition-all hover:scale-110 active:scale-95"
            title="Settings"
          >
            <SettingsIcon size={32} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white/80 backdrop-blur-xl p-8 rounded-[3rem] border border-white/20 shadow-xl text-center glass-morphism">
          <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2">{dict.sessions}</p>
          <p className="text-5xl font-bold text-slate-800">{sessions}</p>
        </div>
        <div className="bg-white/80 backdrop-blur-xl p-8 rounded-[3rem] border border-white/20 shadow-xl text-center glass-morphism">
          <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2">{dict.total_time}</p>
          <p className="text-5xl font-bold text-slate-800">{sessions * pomoWork}m</p>
        </div>
      </div>

      <div className="bg-amber-50/50 backdrop-blur-sm p-8 rounded-[3rem] border border-amber-100/50 flex items-start gap-6 shadow-lg">
        <div className="p-4 bg-amber-100 text-amber-600 rounded-2xl shadow-inner">
          <Bell size={32} />
        </div>
        <div className="space-y-2">
          <h4 className="text-xl font-bold text-amber-900">{dict.tip_title}</h4>
          <p className="text-lg text-amber-800 leading-relaxed">
            {dict.tip_desc}
          </p>
        </div>
      </div>
    </div>
  );
}

function cn(...classes: any[]) {
  return classes.filter(Boolean).join(' ');
}
