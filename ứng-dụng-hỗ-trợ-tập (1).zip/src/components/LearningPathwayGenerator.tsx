import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Map, Sparkles, Loader2, X, Brain, Calendar, Target, Clock, Trophy, Send } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { generatePathway } from '@/src/lib/gemini';
import { cn } from '@/src/lib/utils';
import { toast } from 'sonner';

const LANGUAGES_DICT: Record<string, any> = {
  "Tiếng Việt": {
    "header": "Thiết kế lộ trình học tập chuyên nghiệp",
    "desc": "AI sẽ xây dựng kế hoạch học tập chi tiết, thời gian biểu và lời khuyên từ bạn đồng hành.",
    "goal_label": "Mục tiêu học tập",
    "goal_placeholder": "Ví dụ: Học ReactJS từ cơ bản đến nâng cao...",
    "duration_label": "Thời lượng",
    "duration_placeholder": "Ví dụ: 4 tuần, 3 tháng...",
    "level_label": "Trình độ hiện tại",
    "level_options": ["Mới bắt đầu", "Trung bình", "Nâng cao"],
    "generate_btn": "Tạo lộ trình chuyên nghiệp",
    "generating": "Đang phân tích và xây dựng lộ trình...",
    "clear_btn": "Xóa lộ trình",
    "roadmap_title": "📍 Lộ trình học tập cá nhân",
    "timetable_title": "📅 Thời gian biểu chi tiết",
    "companion_title": "🤖 Lời khuyên từ bạn đồng hành AI",
    "xp_earned": "Bạn đã nhận được 100 XP cho việc lập kế hoạch!",
    "status_thinking": "Đang phân tích mục tiêu...",
    "status_structuring": "Đang thiết kế các giai đoạn...",
    "status_scheduling": "Đang lập thời gian biểu...",
    "status_finalizing": "Đang hoàn thiện lộ trình..."
  },
  "English": {
    "header": "Professional Learning Pathway",
    "desc": "AI will build a detailed study plan, timetable, and advice from your companion.",
    "goal_label": "Learning Goal",
    "goal_placeholder": "Example: Learn ReactJS from scratch...",
    "duration_label": "Duration",
    "duration_placeholder": "Example: 4 weeks, 3 months...",
    "level_label": "Current Level",
    "level_options": ["Beginner", "Intermediate", "Advanced"],
    "generate_btn": "Generate Professional Pathway",
    "generating": "Analyzing and building pathway...",
    "clear_btn": "Clear Pathway",
    "roadmap_title": "📍 Personal Learning Roadmap",
    "timetable_title": "📅 Detailed Timetable",
    "companion_title": "🤖 AI Companion's Advice",
    "xp_earned": "You earned 100 XP for planning!",
    "status_thinking": "Analyzing goals...",
    "status_structuring": "Designing phases...",
    "status_scheduling": "Creating timetable...",
    "status_finalizing": "Finalizing pathway..."
  }
};

export const LearningPathwayGenerator = () => {
  const [goal, setGoal] = useState('');
  const [duration, setDuration] = useState('');
  const [level, setLevel] = useState('Beginner');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [status, setStatus] = useState<string[]>([]);
  const [language, setLanguage] = useState('Tiếng Việt');

  const dict = LANGUAGES_DICT[language] || LANGUAGES_DICT["Tiếng Việt"];

  useEffect(() => {
    const savedLanguage = localStorage.getItem('eduai_language') || 'Tiếng Việt';
    setLanguage(savedLanguage);
    const savedPathway = localStorage.getItem('eduai_pathway_pro');
    if (savedPathway) setResult(savedPathway);
  }, []);

  const handleGenerate = async () => {
    if (!goal || !duration) {
      toast.error(language === 'Tiếng Việt' ? 'Vui lòng nhập đầy đủ thông tin!' : 'Please fill in all fields!');
      return;
    }

    setLoading(true);
    setStatus([dict.status_thinking]);
    setResult('');

    try {
      setTimeout(() => setStatus(prev => [...prev, dict.status_structuring]), 2000);
      setTimeout(() => setStatus(prev => [...prev, dict.status_scheduling]), 4000);
      setTimeout(() => setStatus(prev => [...prev, dict.status_finalizing]), 6000);

      const pathway = await generatePathway(goal, duration, level, language);
      setResult(pathway);
      localStorage.setItem('eduai_pathway_pro', pathway);

      // Update XP
      const currentXP = parseInt(localStorage.getItem('eduai_xp') || '0');
      localStorage.setItem('eduai_xp', (currentXP + 100).toString());
      toast.success(dict.xp_earned);

      // Record History
      const history = JSON.parse(localStorage.getItem('eduai_study_history') || '[]');
      history.unshift({
        date: new Date().toISOString(),
        activity: language === 'Tiếng Việt' ? 'Lập lộ trình học tập' : 'Created Learning Pathway',
        duration: 0,
        result: goal,
        xp: 100
      });
      localStorage.setItem('eduai_study_history', JSON.stringify(history.slice(0, 50)));

    } catch (error) {
      console.error(error);
      toast.error('Error generating pathway');
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setResult('');
    localStorage.removeItem('eduai_pathway_pro');
    setGoal('');
    setDuration('');
    setStatus([]);
  };

  return (
    <div className="space-y-8 pb-20">
      {/* Header Section */}
      <header className="text-center space-y-4">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="inline-flex p-4 bg-brand-500 text-white rounded-3xl shadow-xl shadow-brand-200"
        >
          <Map size={40} />
        </motion.div>
        <h1 className="text-4xl font-bold text-slate-900 tracking-tight">{dict.header}</h1>
        <p className="text-slate-500 max-w-2xl mx-auto text-lg">{dict.desc}</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Input Form - Glassmorphism */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white/80 backdrop-blur-xl border border-white/30 rounded-[2.5rem] p-8 shadow-2xl shadow-slate-200/50 sticky top-8">
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                  <Target size={16} className="text-brand-500" />
                  {dict.goal_label}
                </label>
                <textarea
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                  placeholder={dict.goal_placeholder}
                  className="w-full p-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-brand-500 min-h-[120px] transition-all"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                  <Clock size={16} className="text-brand-500" />
                  {dict.duration_label}
                </label>
                <input
                  type="text"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  placeholder={dict.duration_placeholder}
                  className="w-full p-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-brand-500 transition-all"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                  <Trophy size={16} className="text-brand-500" />
                  {dict.level_label}
                </label>
                <div className="grid grid-cols-1 gap-2">
                  {dict.level_options.map((opt: string) => (
                    <button
                      key={opt}
                      onClick={() => setLevel(opt)}
                      className={cn(
                        "p-3 rounded-xl text-sm font-medium transition-all text-left px-4",
                        level === opt 
                          ? "bg-brand-500 text-white shadow-lg shadow-brand-200" 
                          : "bg-slate-50 text-slate-600 hover:bg-slate-100"
                      )}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={handleGenerate}
                disabled={loading}
                className="w-full py-4 bg-brand-500 text-white rounded-2xl font-bold shadow-xl shadow-brand-200 hover:bg-brand-600 disabled:opacity-50 transition-all flex items-center justify-center gap-2 group"
              >
                {loading ? (
                  <Loader2 className="animate-spin" />
                ) : (
                  <>
                    <Send size={20} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                    {dict.generate_btn}
                  </>
                )}
              </button>

              {result && (
                <button
                  onClick={handleClear}
                  className="w-full py-3 text-slate-400 hover:text-red-500 font-medium transition-colors"
                >
                  {dict.clear_btn}
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Result Display */}
        <div className="lg:col-span-8">
          <AnimatePresence mode="wait">
            {loading ? (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white/80 backdrop-blur-xl border border-white/30 rounded-[2.5rem] p-12 shadow-2xl flex flex-col items-center justify-center min-h-[400px] space-y-8"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-brand-200 blur-3xl opacity-30 animate-pulse" />
                  <Loader2 size={64} className="text-brand-500 animate-spin relative z-10" />
                </div>
                <div className="space-y-4 text-center">
                  <h3 className="text-2xl font-bold text-slate-800">{dict.generating}</h3>
                  <div className="flex flex-col gap-2">
                    {status.map((s, i) => (
                      <motion.p
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="text-slate-400 flex items-center gap-2 justify-center"
                      >
                        <Sparkles size={14} className="text-brand-400" />
                        {s}
                      </motion.p>
                    ))}
                  </div>
                </div>
              </motion.div>
            ) : result ? (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
              >
                {/* AI Companion Section */}
                <div className="bg-brand-50 border border-brand-100 rounded-[2rem] p-8 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform">
                    <Brain size={120} />
                  </div>
                  <div className="relative z-10 space-y-4">
                    <div className="flex items-center gap-3 text-brand-600 font-bold text-xl">
                      <Sparkles size={24} />
                      {dict.companion_title}
                    </div>
                    <div className="prose prose-brand max-w-none italic text-brand-800/80 text-lg leading-relaxed">
                      <ReactMarkdown>
                        {result.split('### AI Companion\'s Encouragement')[1] || 'Hãy bắt đầu hành trình của bạn ngay hôm nay!'}
                      </ReactMarkdown>
                    </div>
                  </div>
                </div>

                {/* Main Roadmap Table */}
                <div className="bg-white/80 backdrop-blur-xl border border-white/30 rounded-[2.5rem] p-8 shadow-2xl shadow-slate-200/50">
                  <div className="flex items-center gap-3 mb-8 text-slate-800 font-bold text-2xl">
                    <Calendar size={28} className="text-brand-500" />
                    {dict.roadmap_title}
                  </div>
                  <div className="markdown-body prose prose-slate max-w-none prose-headings:text-brand-600 prose-table:border-collapse prose-th:bg-slate-50 prose-th:p-4 prose-td:p-4">
                    <ReactMarkdown>
                      {result.split('### Weekly Timetable')[0].replace('### Learning Roadmap', '')}
                    </ReactMarkdown>
                  </div>
                </div>

                {/* Timetable Section */}
                <div className="bg-white/80 backdrop-blur-xl border border-white/30 rounded-[2.5rem] p-8 shadow-2xl shadow-slate-200/50">
                  <div className="flex items-center gap-3 mb-8 text-slate-800 font-bold text-2xl">
                    <Clock size={28} className="text-brand-500" />
                    {dict.timetable_title}
                  </div>
                  <div className="markdown-body prose prose-slate max-w-none">
                    <ReactMarkdown>
                      {result.split('### Weekly Timetable')[1]?.split('### AI Companion\'s Encouragement')[0] || ''}
                    </ReactMarkdown>
                  </div>
                </div>
              </motion.div>
            ) : (
              <div className="bg-slate-100/50 border-2 border-dashed border-slate-200 rounded-[2.5rem] p-20 flex flex-col items-center justify-center text-center space-y-6">
                <div className="p-6 bg-white rounded-full shadow-sm text-slate-300">
                  <Map size={64} />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-slate-400">Chưa có lộ trình nào được tạo</h3>
                  <p className="text-slate-400 max-w-xs">Nhập mục tiêu của bạn ở bên trái để AI bắt đầu xây dựng kế hoạch.</p>
                </div>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
