import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Map, Sparkles, Loader2, X, Brain } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { generatePathway } from '@/src/lib/gemini';

const LANGUAGES_DICT: Record<string, any> = {
  "Tiếng Việt": {
    "header": "Thiết kế lộ trình học tập",
    "desc": "AI sẽ xây dựng kế hoạch học tập chi tiết theo thời gian bạn yêu cầu.",
    "goal_label": "Môn học / Mục tiêu",
    "goal_placeholder": "Ví dụ: Tiếng Anh giao tiếp, Giải tích 1...",
    "days_label": "Số ngày học",
    "level_label": "Trình độ",
    "level_beginner": "Mới bắt đầu",
    "level_intermediate": "Trung bình",
    "level_advanced": "Nâng cao",
    "btn_generate": "Tạo lộ trình ngay",
    "status_analyzing": "Đang phân tích mục tiêu...",
    "status_optimizing": "Đang tối ưu cho trình độ",
    "status_building": "Đang xây dựng lộ trình chi tiết...",
    "status_done": "Đã hoàn thành!",
    "status_error": "Lỗi khi tạo lộ trình.",
    "clear_tooltip": "Xóa lộ trình",
    "timetable_title": "Thời gian biểu dự kiến",
    "companion_note": "Lời nhắn từ AI Đồng hành"
  },
  "English": {
    "header": "Design Learning Pathway",
    "desc": "AI will build a detailed study plan based on your requested time.",
    "goal_label": "Subject / Goal",
    "goal_placeholder": "Example: Conversational English, Calculus 1...",
    "days_label": "Number of days",
    "level_label": "Level",
    "level_beginner": "Beginner",
    "level_intermediate": "Intermediate",
    "level_advanced": "Advanced",
    "btn_generate": "Generate Pathway Now",
    "status_analyzing": "Analyzing goal...",
    "status_optimizing": "Optimizing for level",
    "status_building": "Building detailed pathway...",
    "status_done": "Completed!",
    "status_error": "Error generating pathway.",
    "clear_tooltip": "Clear pathway",
    "timetable_title": "Estimated Timetable",
    "companion_note": "Message from AI Companion"
  },
  "Français": {
    "header": "Concevoir un parcours d'apprentissage",
    "desc": "L'IA élaborera un plan d'étude détaillé en fonction du temps demandé.",
    "goal_label": "Sujet / Objectif",
    "goal_placeholder": "Exemple : Anglais conversationnel, Calcul 1...",
    "days_label": "Nombre de jours",
    "level_label": "Niveau",
    "level_beginner": "Débutant",
    "level_intermediate": "Intermédiaire",
    "level_advanced": "Avancé",
    "btn_generate": "Générer le parcours maintenant",
    "status_analyzing": "Analyse de l'objectif...",
    "status_optimizing": "Optimisation pour le niveau",
    "status_building": "Construction du parcours détaillé...",
    "status_done": "Terminé !",
    "status_error": "Erreur lors de la génération du parcours.",
    "clear_tooltip": "Effacer le parcours"
  },
  "日本語": {
    "header": "学習パスウェイの設計",
    "desc": "AIが要求された時間に基づいて詳細な学習計画を作成します。",
    "goal_label": "科目 / 目標",
    "goal_placeholder": "例：英会話、微積分1...",
    "days_label": "日数",
    "level_label": "レベル",
    "level_beginner": "初心者",
    "level_intermediate": "中級者",
    "level_advanced": "上級者",
    "btn_generate": "今すぐパスウェイを生成",
    "status_analyzing": "目標を分析中...",
    "status_optimizing": "レベルに合わせて最適化中",
    "status_building": "詳細なパスウェイを構築中...",
    "status_done": "完了しました！",
    "status_error": "パスウェイの生成中にエラーが発生しました。",
    "clear_tooltip": "パスウェイをクリア"
  },
  "Deutsch": {
    "header": "Lernpfad entwerfen",
    "desc": "Die KI erstellt einen detaillierten Lernplan basierend auf der von Ihnen angeforderten Zeit.",
    "goal_label": "Fach / Ziel",
    "goal_placeholder": "Beispiel: Konversationsenglisch, Analysis 1...",
    "days_label": "Anzahl der Tage",
    "level_label": "Niveau",
    "level_beginner": "Anfänger",
    "level_intermediate": "Mittel",
    "level_advanced": "Fortgeschritten",
    "btn_generate": "Pfad jetzt generieren",
    "status_analyzing": "Ziel wird analysiert...",
    "status_optimizing": "Optimierung für Niveau",
    "status_building": "Detaillierter Pfad wird erstellt...",
    "status_done": "Abgeschlossen!",
    "status_error": "Fehler beim Generieren des Pfads.",
    "clear_tooltip": "Pfad löschen"
  },
  "Español": {
    "header": "Diseñar Ruta de Aprendizaje",
    "desc": "La IA construirá un plan de estudio detallado basado en el tiempo solicitado.",
    "goal_label": "Materia / Objetivo",
    "goal_placeholder": "Ejemplo: Inglés conversacional, Cálculo 1...",
    "days_label": "Número de días",
    "level_label": "Nivel",
    "level_beginner": "Principiante",
    "level_intermediate": "Intermedio",
    "level_advanced": "Avanzado",
    "btn_generate": "Generar Ruta Ahora",
    "status_analyzing": "Analizando objetivo...",
    "status_optimizing": "Optimizando para el nivel",
    "status_building": "Construyendo ruta detallada...",
    "status_done": "¡Completado!",
    "status_error": "Error al generar la ruta.",
    "clear_tooltip": "Borrar ruta"
  },
  "한국어": {
    "header": "학습 경로 설계",
    "desc": "AI가 요청하신 시간에 맞춰 상세한 학습 계획을 세워드립니다.",
    "goal_label": "과목 / 목표",
    "goal_placeholder": "예: 회화 영어, 미적분 1...",
    "days_label": "일수",
    "level_label": "수준",
    "level_beginner": "초보자",
    "level_intermediate": "중급자",
    "level_advanced": "상급자",
    "btn_generate": "지금 경로 생성",
    "status_analyzing": "목표 분석 중...",
    "status_optimizing": "수준에 맞춰 최적화 중",
    "status_building": "상세 경로 구축 중...",
    "status_done": "완료되었습니다!",
    "status_error": "경로 생성 중 오류가 발생했습니다.",
    "clear_tooltip": "경로 지우기"
  }
};

export function Pathway() {
  const [goal, setGoal] = useState('');
  const [days, setDays] = useState(7);
  const [level, setLevel] = useState('Beginner');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [status, setStatus] = useState<string[]>([]);
  const [language, setLanguage] = useState('Tiếng Việt');

  const dict = LANGUAGES_DICT[language] || LANGUAGES_DICT['Tiếng Việt'];

  // Load saved pathway and settings on mount
  React.useEffect(() => {
    const saved = localStorage.getItem('eduai_pathway');
    if (saved) setResult(saved);

    const savedSettings = localStorage.getItem('eduai_settings');
    if (savedSettings) {
      setLanguage(JSON.parse(savedSettings).language || 'Tiếng Việt');
    }
  }, []);

  const handleGenerate = async () => {
    if (!goal) return;
    setLoading(true);
    setResult('');
    setStatus([dict.status_analyzing]);
    
    try {
      setTimeout(() => setStatus(prev => [...prev, `${dict.status_optimizing} ${level}...`]), 1000);
      setTimeout(() => setStatus(prev => [...prev, dict.status_building]), 2000);
      
      const res = await generatePathway(goal, `${days} ngày`, level, language);
      setResult(res);
      localStorage.setItem('eduai_pathway', res);
      setStatus(prev => [...prev, dict.status_done]);

      // Record study history and XP
      const currentXp = parseInt(localStorage.getItem('eduai_xp') || '0');
      const newXp = currentXp + 100;
      localStorage.setItem('eduai_xp', newXp.toString());

      const history = JSON.parse(localStorage.getItem('eduai_study_history') || '[]');
      history.unshift({
        date: new Date().toISOString(),
        activity: language === 'Tiếng Việt' ? 'Tạo lộ trình học tập' : 'Generate Learning Pathway',
        duration: 15,
        result: language === 'Tiếng Việt' ? 'Đã thiết kế' : 'Designed',
        xp: 100
      });
      localStorage.setItem('eduai_study_history', JSON.stringify(history.slice(0, 50)));
    } catch (error) {
      console.error(error);
      setStatus(prev => [...prev, dict.status_error]);
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setResult('');
    localStorage.removeItem('eduai_pathway');
    setStatus([]);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-12 py-8 px-4">
      <header className="text-center space-y-6">
        <div className="inline-flex p-6 bg-brand-500 text-white rounded-[2.5rem] shadow-2xl shadow-brand-200 rotate-3">
          <Map size={56} />
        </div>
        <h2 className="text-5xl font-display font-bold text-slate-800">{dict.header}</h2>
        <p className="text-slate-500 text-2xl max-w-3xl mx-auto">{dict.desc}</p>
      </header>

      <div className="bg-white/80 backdrop-blur-2xl p-12 rounded-[4rem] border border-white/20 shadow-2xl space-y-10 glass-morphism">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div className="md:col-span-2 space-y-4">
            <label className="text-sm font-bold text-slate-400 uppercase tracking-widest ml-2">{dict.goal_label}</label>
            <input
              type="text"
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              placeholder={dict.goal_placeholder}
              className="w-full px-8 py-5 rounded-[2rem] border border-slate-200 focus:ring-8 focus:ring-brand-500/10 focus:border-brand-500 outline-none transition-all text-xl bg-white/50 shadow-inner"
            />
          </div>
          <div className="space-y-4">
            <label className="text-sm font-bold text-slate-400 uppercase tracking-widest ml-2">{dict.days_label}</label>
            <input
              type="number"
              min="1"
              value={days}
              onChange={(e) => setDays(parseInt(e.target.value) || 1)}
              className="w-full px-8 py-5 rounded-[2rem] border border-slate-200 focus:ring-8 focus:ring-brand-500/10 focus:border-brand-500 outline-none transition-all text-xl bg-white/50 shadow-inner"
            />
          </div>
          <div className="space-y-4">
            <label className="text-sm font-bold text-slate-400 uppercase tracking-widest ml-2">{dict.level_label}</label>
            <select
              value={level}
              onChange={(e) => setLevel(e.target.value)}
              className="w-full px-8 py-5 rounded-[2rem] border border-slate-200 focus:ring-8 focus:ring-brand-500/10 focus:border-brand-500 outline-none transition-all text-xl bg-white/50 appearance-none cursor-pointer shadow-inner"
            >
              <option value="Beginner">{dict.level_beginner}</option>
              <option value="Intermediate">{dict.level_intermediate}</option>
              <option value="Advanced">{dict.level_advanced}</option>
            </select>
          </div>
        </div>

        <button
          onClick={handleGenerate}
          disabled={loading || !goal}
          className="w-full bg-slate-900 text-white py-8 rounded-[2.5rem] font-bold text-2xl flex items-center justify-center gap-4 hover:bg-slate-800 transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed shadow-2xl shadow-slate-200"
        >
          {loading ? (
            <Loader2 className="animate-spin" size={36} />
          ) : (
            <>
              <Sparkles size={36} />
              {dict.btn_generate}
            </>
          )}
        </button>

        <AnimatePresence>
          {loading && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-slate-50/50 p-8 rounded-[2.5rem] space-y-4 border border-slate-100/50 shadow-inner"
            >
              {status.map((s, i) => (
                <motion.div 
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  key={i} 
                  className="flex items-center gap-4 text-lg text-slate-600 font-bold"
                >
                  <div className="w-3 h-3 bg-brand-500 rounded-full animate-pulse shadow-lg shadow-brand-200"></div>
                  {s}
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {result && (
        <div className="space-y-12">
          {/* AI Companion Message */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-slate-900 text-white p-10 rounded-[3.5rem] shadow-2xl relative overflow-hidden"
          >
            <div className="absolute -right-10 -top-10 opacity-10">
              <Sparkles size={180} />
            </div>
            <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
              <div className="p-6 bg-brand-500 rounded-[2rem] shadow-xl">
                <Brain size={48} />
              </div>
              <div className="space-y-2 text-center md:text-left">
                <h3 className="text-2xl font-bold">{dict.companion_note}</h3>
                <p className="text-slate-400 text-lg italic leading-relaxed">
                  {language === 'Tiếng Việt' 
                    ? '"Chào bạn! Mình đã thiết kế một lộ trình cá nhân hóa dành riêng cho bạn. Hãy cùng nhau chinh phục mục tiêu này nhé!"'
                    : '"Hi there! I\'ve designed a personalized roadmap just for you. Let\'s conquer this goal together!"'}
                </p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/80 backdrop-blur-2xl p-12 lg:p-16 rounded-[4rem] border border-white/20 shadow-2xl relative group glass-morphism"
          >
          <button 
            onClick={handleClear}
            className="absolute top-10 right-10 p-4 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-2xl transition-all opacity-0 group-hover:opacity-100 shadow-xl border border-transparent hover:border-red-100"
            title={dict.clear_tooltip}
          >
            <X size={32} />
          </button>
          <div className="markdown-body prose-2xl max-w-none">
            <ReactMarkdown>{result}</ReactMarkdown>
          </div>
        </motion.div>
      </div>
    )}
  </div>
  );
}
