/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  BookOpen, 
  Timer, 
  History, 
  User as UserIcon,
  Sparkles,
  Zap,
  GraduationCap,
  Menu,
  X
} from 'lucide-react';

// Import các component chúng ta đã viết
import { Pathway } from './components/Pathway';
import { Pomodoro } from './components/Pomodoro';
import { Logs } from './components/Logs';
import { cn } from './lib/utils';

export default function EduAIApp() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [userStats, setUserStats] = useState({ xp: 0, level: 1, streak: 0 });
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  useEffect(() => {
    // Đồng bộ dữ liệu hệ thống
    const xp = parseInt(localStorage.getItem('eduai_xp') || '0');
    const level = Math.floor(xp / 500) + 1;
    setUserStats({ xp, level, streak: 5 }); // Giả định streak là 5
  }, [activeTab]);

  const navItems = [
    { id: 'dashboard', icon: <LayoutDashboard size={20} />, label: 'Tổng quan' },
    { id: 'pathway', icon: <BookOpen size={20} />, label: 'Lộ trình' },
    { id: 'pomodoro', icon: <Timer size={20} />, label: 'Tập trung' },
    { id: 'logs', icon: <History size={20} />, label: 'Nhật ký' },
  ];

  const SidebarContent = () => (
    <>
      <div className="flex items-center gap-3 px-2 mb-10">
        <div className="p-2 bg-brand-500 rounded-xl text-white shadow-lg shadow-brand-200">
          <GraduationCap size={28} />
        </div>
        <h1 className="text-2xl font-black tracking-tighter">EduAI</h1>
      </div>

      <nav className="flex-1 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => {
              setActiveTab(item.id);
              setIsSidebarOpen(false);
            }}
            className={cn(
              "w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl font-bold transition-all",
              activeTab === item.id 
                ? 'bg-brand-50 text-brand-600 shadow-sm' 
                : 'text-slate-400 hover:bg-slate-50 hover:text-slate-600'
            )}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </nav>

      {/* User Card - Hệ thống Gamification */}
      <div className="bg-slate-900 rounded-[2rem] p-6 text-white relative overflow-hidden mt-auto">
        <div className="relative z-10">
          <p className="text-xs font-bold text-slate-400 uppercase mb-4">Cấp độ {userStats.level}</p>
          <div className="flex items-end justify-between mb-2">
            <span className="text-2xl font-bold">{userStats.xp} XP</span>
            <Zap size={20} className="text-brand-400 fill-brand-400" />
          </div>
          <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${(userStats.xp % 500) / 5}%` }}
              className="h-full bg-brand-500"
            />
          </div>
        </div>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex font-sans text-slate-900">
      {/* DESKTOP SIDEBAR */}
      <aside className="w-72 bg-white border-r border-slate-100 flex flex-col p-6 hidden lg:flex sticky top-0 h-screen">
        <SidebarContent />
      </aside>

      {/* MOBILE SIDEBAR */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[60] lg:hidden"
            />
            <motion.aside
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              className="fixed inset-y-0 left-0 w-72 bg-white p-6 z-[70] lg:hidden flex flex-col shadow-2xl"
            >
              <SidebarContent />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* MAIN CONTENT */}
      <main className="flex-1 flex flex-col min-h-screen">
        {/* TOP BAR */}
        <header className="h-20 bg-white/80 backdrop-blur-md border-b border-slate-100 px-4 md:px-8 flex items-center justify-between sticky top-0 z-50">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 text-slate-500 hover:bg-slate-50 rounded-xl lg:hidden"
            >
              <Menu size={24} />
            </button>
            <div className="flex items-center gap-2 text-slate-400 font-medium text-sm md:text-base">
              <span className="hidden md:inline">Ứng dụng</span> 
              <span className="hidden md:inline">/</span> 
              <span className="text-slate-900 font-bold capitalize">{activeTab}</span>
            </div>
          </div>
          
          <div className="flex items-center gap-3 md:gap-4">
             <div className="flex items-center gap-2 px-3 md:px-4 py-2 bg-amber-50 text-amber-600 rounded-full font-bold text-xs md:text-sm">
                <Sparkles size={16} fill="currentColor" />
                {userStats.streak} <span className="hidden sm:inline">Ngày liên tiếp</span>
             </div>
             <div className="w-10 h-10 bg-slate-200 rounded-full flex items-center justify-center border-2 border-white shadow-sm overflow-hidden">
                <UserIcon size={20} className="text-slate-500" />
             </div>
          </div>
        </header>

        {/* DYNAMIC CONTENT */}
        <section className="p-4 md:p-8 flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              {activeTab === 'dashboard' && <WelcomeDashboard stats={userStats} setActiveTab={setActiveTab} />}
              {activeTab === 'pathway' && <Pathway />}
              {activeTab === 'pomodoro' && <Pomodoro />}
              {activeTab === 'logs' && <Logs setActiveTab={setActiveTab} />}
            </motion.div>
          </AnimatePresence>
        </section>
      </main>
    </div>
  );
}

// Sub-component cho trang Dashboard
function WelcomeDashboard({ stats, setActiveTab }: any) {
  return (
    <div className="space-y-10">
      <div className="space-y-2">
        <h2 className="text-3xl md:text-4xl font-bold text-slate-800">Chào mừng trở lại! 👋</h2>
        <p className="text-slate-500 text-lg md:text-xl">Hôm nay bạn muốn bắt đầu học môn gì nào?</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 md:gap-8">
        <QuickActionCard 
          title="Tạo lộ trình mới" 
          desc="AI thiết kế kế hoạch học tập chỉ trong 5 giây."
          icon={<BookOpen size={32} />}
          onClick={() => setActiveTab('pathway')}
          color="bg-brand-500"
        />
        <QuickActionCard 
          title="Vào phiên tập trung" 
          desc="Sử dụng Pomodoro để hoàn thành bài tập nhanh hơn."
          icon={<Timer size={32} />}
          onClick={() => setActiveTab('pomodoro')}
          color="bg-slate-900"
        />
        <QuickActionCard 
          title="Kiểm tra lịch sử" 
          desc="Xem lại các phiên học và thành tích đã đạt."
          icon={<History size={32} />}
          onClick={() => setActiveTab('logs')}
          color="bg-emerald-500"
        />
      </div>
    </div>
  );
}

function QuickActionCard({ title, desc, icon, onClick, color }: any) {
  return (
    <button 
      onClick={onClick}
      className="bg-white p-6 md:p-8 rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/50 text-left hover:scale-[1.03] transition-all group"
    >
      <div className={cn(
        "p-4 text-white rounded-2xl w-fit mb-6 shadow-lg group-hover:rotate-12 transition-transform",
        color
      )}>
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-slate-500 leading-relaxed">{desc}</p>
    </button>
  );
}

