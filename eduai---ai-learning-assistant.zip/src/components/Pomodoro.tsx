import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, RotateCcw, Coffee, Brain, Bell } from 'lucide-react';
import { cn } from '../lib/utils';

export function Pomodoro() {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<'work' | 'break'>('work');
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const totalTime = mode === 'work' ? 25 * 60 : 5 * 60;
  const progress = ((totalTime - timeLeft) / totalTime) * 100;

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      handleTimerComplete();
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, timeLeft]);

  const handleTimerComplete = () => {
    setIsActive(false);
    if (timerRef.current) clearInterval(timerRef.current);
    
    // Play notification sound if possible
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
    audio.play().catch(() => {});

    if (mode === 'work') {
      // Add XP and Log
      const currentXp = parseInt(localStorage.getItem('eduai_xp') || '0');
      localStorage.setItem('eduai_xp', (currentXp + 100).toString());
      
      const logs = JSON.parse(localStorage.getItem('eduai_logs') || '[]');
      logs.unshift({
        id: Date.now(),
        type: 'pomodoro',
        title: 'Hoàn thành phiên tập trung',
        timestamp: new Date().toISOString(),
        content: 'Bạn đã hoàn thành 25 phút tập trung cao độ. +100 XP'
      });
      localStorage.setItem('eduai_logs', JSON.stringify(logs.slice(0, 50)));

      setMode('break');
      setTimeLeft(5 * 60);
    } else {
      setMode('work');
      setTimeLeft(25 * 60);
    }
  };

  const toggleTimer = () => setIsActive(!isActive);

  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(mode === 'work' ? 25 * 60 : 5 * 60);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-2xl mx-auto flex flex-col items-center space-y-12 py-10">
      <div className="flex gap-4 p-2 bg-white rounded-2xl border border-slate-100 shadow-sm">
        <button
          onClick={() => { setMode('work'); setTimeLeft(25 * 60); setIsActive(false); }}
          className={cn(
            "px-6 py-2 rounded-xl font-bold transition-all flex items-center gap-2",
            mode === 'work' ? "bg-brand-500 text-white shadow-lg shadow-brand-200" : "text-slate-400 hover:text-slate-600"
          )}
        >
          <Brain size={18} /> Tập trung
        </button>
        <button
          onClick={() => { setMode('break'); setTimeLeft(5 * 60); setIsActive(false); }}
          className={cn(
            "px-6 py-2 rounded-xl font-bold transition-all flex items-center gap-2",
            mode === 'break' ? "bg-emerald-500 text-white shadow-lg shadow-emerald-200" : "text-slate-400 hover:text-slate-600"
          )}
        >
          <Coffee size={18} /> Nghỉ ngơi
        </button>
      </div>

      <div className="relative w-80 h-80 flex items-center justify-center">
        {/* Progress Circle */}
        <svg className="w-full h-full -rotate-90">
          <circle
            cx="160"
            cy="160"
            r="150"
            fill="none"
            stroke="currentColor"
            strokeWidth="12"
            className="text-slate-100"
          />
          <motion.circle
            cx="160"
            cy="160"
            r="150"
            fill="none"
            stroke="currentColor"
            strokeWidth="12"
            strokeDasharray="942.48"
            animate={{ strokeDashoffset: 942.48 - (942.48 * progress) / 100 }}
            className={cn(
              "transition-all duration-1000",
              mode === 'work' ? "text-brand-500" : "text-emerald-500"
            )}
          />
        </svg>

        <div className="absolute flex flex-col items-center">
          <span className="text-7xl font-black tracking-tighter text-slate-800 tabular-nums">
            {formatTime(timeLeft)}
          </span>
          <span className="text-slate-400 font-bold uppercase tracking-widest mt-2">
            {mode === 'work' ? 'Focusing' : 'Resting'}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-6">
        <button
          onClick={resetTimer}
          className="p-4 bg-white border border-slate-100 text-slate-400 rounded-full hover:text-slate-600 hover:bg-slate-50 transition-all shadow-lg"
        >
          <RotateCcw size={28} />
        </button>
        
        <button
          onClick={toggleTimer}
          className={cn(
            "w-24 h-24 rounded-full flex items-center justify-center text-white shadow-2xl transition-all hover:scale-105 active:scale-95",
            mode === 'work' ? "bg-brand-500 shadow-brand-200" : "bg-emerald-500 shadow-emerald-200"
          )}
        >
          {isActive ? <Pause size={40} fill="currentColor" /> : <Play size={40} fill="currentColor" className="ml-2" />}
        </button>

        <button
          className="p-4 bg-white border border-slate-100 text-slate-400 rounded-full hover:text-slate-600 hover:bg-slate-50 transition-all shadow-lg"
        >
          <Bell size={28} />
        </button>
      </div>
    </div>
  );
}
