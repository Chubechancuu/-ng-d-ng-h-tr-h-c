import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { History, BookOpen, Timer, Trash2, ChevronRight, Calendar, ArrowUpDown, Filter } from 'lucide-react';
import { cn } from '../lib/utils';
import ReactMarkdown from 'react-markdown';

interface LogEntry {
  id: number;
  type: 'pathway' | 'pomodoro';
  title: string;
  timestamp: string;
  content: string;
}

type SortOption = 'newest' | 'oldest' | 'type';

export function Logs({ setActiveTab }: { setActiveTab: (tab: string) => void }) {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [selectedLog, setSelectedLog] = useState<LogEntry | null>(null);
  const [sortBy, setSortBy] = useState<SortOption>('newest');

  useEffect(() => {
    const savedLogs = JSON.parse(localStorage.getItem('eduai_logs') || '[]');
    setLogs(savedLogs);
  }, []);

  const sortedLogs = useMemo(() => {
    return [...logs].sort((a, b) => {
      if (sortBy === 'newest') return b.id - a.id;
      if (sortBy === 'oldest') return a.id - b.id;
      if (sortBy === 'type') return a.type.localeCompare(b.type);
      return 0;
    });
  }, [logs, sortBy]);

  const clearLogs = () => {
    if (confirm('Bạn có chắc chắn muốn xóa tất cả nhật ký?')) {
      localStorage.setItem('eduai_logs', '[]');
      setLogs([]);
      setSelectedLog(null);
    }
  };

  const formatDate = (isoString: string) => {
    const date = new Date(isoString);
    return date.toLocaleString('vi-VN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* List side */}
      <div className="lg:col-span-5 space-y-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <History className="text-brand-500" /> Nhật ký học tập
          </h2>
          {logs.length > 0 && (
            <div className="flex items-center gap-2">
              <button 
                onClick={clearLogs}
                className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                title="Xóa tất cả"
              >
                <Trash2 size={20} />
              </button>
            </div>
          )}
        </div>

        {logs.length > 0 && (
          <div className="flex items-center gap-4 bg-white p-2 rounded-2xl border border-slate-100 shadow-sm">
            <div className="flex items-center gap-2 px-3 text-slate-400">
              <ArrowUpDown size={16} />
              <span className="text-xs font-bold uppercase tracking-wider">Sắp xếp</span>
            </div>
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="flex-1 bg-transparent border-none outline-none text-sm font-bold text-slate-600 cursor-pointer"
            >
              <option value="newest">Mới nhất</option>
              <option value="oldest">Cũ nhất</option>
              <option value="type">Theo loại</option>
            </select>
          </div>
        )}

        {logs.length === 0 ? (
          <div className="bg-white p-10 rounded-[2.5rem] border border-dashed border-slate-200 text-center space-y-4">
            <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-300">
              <History size={32} />
            </div>
            <p className="text-slate-500 font-medium">Chưa có hoạt động nào được ghi lại.</p>
            <button 
              onClick={() => setActiveTab('pathway')}
              className="text-brand-600 font-bold hover:underline"
            >
              Bắt đầu học ngay →
            </button>
          </div>
        ) : (
          <div className="space-y-4 overflow-y-auto max-h-[70vh] pr-2 custom-scrollbar">
            {sortedLogs.map((log) => (
              <button
                key={log.id}
                onClick={() => setSelectedLog(log)}
                className={cn(
                  "w-full p-5 rounded-2xl border text-left transition-all flex items-start gap-4 group",
                  selectedLog?.id === log.id 
                    ? "bg-brand-50 border-brand-200 shadow-sm" 
                    : "bg-white border-slate-100 hover:border-slate-200 hover:shadow-md"
                )}
              >
                <div className={cn(
                  "p-3 rounded-xl",
                  log.type === 'pathway' ? "bg-brand-100 text-brand-600" : "bg-emerald-100 text-emerald-600"
                )}>
                  {log.type === 'pathway' ? <BookOpen size={20} /> : <Timer size={20} />}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-slate-800 truncate">{log.title}</h3>
                  <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                    <Calendar size={12} /> {formatDate(log.timestamp)}
                  </p>
                </div>
                <ChevronRight className={cn(
                  "mt-2 transition-transform",
                  selectedLog?.id === log.id ? "translate-x-1 text-brand-500" : "text-slate-300 group-hover:translate-x-1"
                )} size={20} />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Content side */}
      <div className="lg:col-span-7">
        <AnimatePresence mode="wait">
          {selectedLog ? (
            <motion.div
              key={selectedLog.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/50 min-h-[400px]"
            >
              <div className="flex items-center gap-4 mb-8 pb-6 border-b border-slate-50">
                <div className={cn(
                  "p-4 rounded-2xl text-white",
                  selectedLog.type === 'pathway' ? "bg-brand-500" : "bg-emerald-500"
                )}>
                  {selectedLog.type === 'pathway' ? <BookOpen size={28} /> : <Timer size={28} />}
                </div>
                <div>
                  <h2 className="text-2xl font-bold">{selectedLog.title}</h2>
                  <p className="text-slate-400 font-medium">{formatDate(selectedLog.timestamp)}</p>
                </div>
              </div>

              <div className="prose prose-slate max-w-none">
                {selectedLog.type === 'pathway' ? (
                  <ReactMarkdown>{selectedLog.content}</ReactMarkdown>
                ) : (
                  <p className="text-lg text-slate-600 leading-relaxed">{selectedLog.content}</p>
                )}
              </div>
            </motion.div>
          ) : (
            <div className="h-full flex items-center justify-center bg-slate-50/50 rounded-[2.5rem] border border-dashed border-slate-200 p-10 text-center">
              <div className="max-w-xs space-y-4">
                <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center mx-auto shadow-sm text-slate-200">
                  <BookOpen size={40} />
                </div>
                <p className="text-slate-400 font-medium">Chọn một mục nhật ký để xem chi tiết nội dung học tập của bạn.</p>
              </div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
