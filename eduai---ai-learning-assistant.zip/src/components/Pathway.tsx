import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Send, BookOpen, Target, Loader2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { generateLearningPathway } from '../lib/gemini';
import { cn } from '../lib/utils';

export function Pathway() {
  const [subject, setSubject] = useState('');
  const [goal, setGoal] = useState('');
  const [loading, setLoading] = useState(false);
  const [pathway, setPathway] = useState<string | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject || !goal) return;

    setLoading(true);
    const result = await generateLearningPathway(subject, goal);
    setPathway(result);
    setLoading(false);

    // Save to logs
    const logs = JSON.parse(localStorage.getItem('eduai_logs') || '[]');
    logs.unshift({
      id: Date.now(),
      type: 'pathway',
      title: `Lộ trình: ${subject}`,
      timestamp: new Date().toISOString(),
      content: result
    });
    localStorage.setItem('eduai_logs', JSON.stringify(logs.slice(0, 50)));
    
    // Add XP
    const currentXp = parseInt(localStorage.getItem('eduai_xp') || '0');
    localStorage.setItem('eduai_xp', (currentXp + 50).toString());
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/50">
        <div className="flex items-center gap-4 mb-8">
          <div className="p-3 bg-brand-500 text-white rounded-2xl shadow-lg shadow-brand-200">
            <Sparkles size={24} />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Tạo lộ trình học tập AI</h2>
            <p className="text-slate-500">Nhập môn học và mục tiêu của bạn để AI thiết kế lộ trình.</p>
          </div>
        </div>

        <form onSubmit={handleGenerate} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 ml-2 flex items-center gap-2">
                <BookOpen size={16} /> Môn học
              </label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Ví dụ: Lập trình React, Tiếng Anh giao tiếp..."
                className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-brand-500 focus:bg-white outline-none transition-all"
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 ml-2 flex items-center gap-2">
                <Target size={16} /> Mục tiêu
              </label>
              <input
                type="text"
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                placeholder="Ví dụ: Đi làm sau 6 tháng, Thi IELTS 7.0..."
                className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-brand-500 focus:bg-white outline-none transition-all"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className={cn(
              "w-full py-4 bg-brand-600 text-white rounded-2xl font-bold shadow-lg shadow-brand-200 hover:bg-brand-700 transition-all flex items-center justify-center gap-2",
              loading && "opacity-70 cursor-not-allowed"
            )}
          >
            {loading ? (
              <>
                <Loader2 className="animate-spin" size={20} />
                Đang thiết kế lộ trình...
              </>
            ) : (
              <>
                <Send size={20} />
                Tạo lộ trình ngay
              </>
            )}
          </button>
        </form>
      </div>

      {pathway && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/50 prose prose-slate max-w-none"
        >
          <ReactMarkdown>{pathway}</ReactMarkdown>
        </motion.div>
      )}
    </div>
  );
}
