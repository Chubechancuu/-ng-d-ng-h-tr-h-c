import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({ apiKey: apiKey || "" });

export async function generateLearningPathway(subject: string, goal: string) {
  const prompt = `Bạn là một chuyên gia giáo dục AI. Hãy tạo một lộ trình học tập chi tiết cho môn học: "${subject}" với mục tiêu: "${goal}".
  Lộ trình nên bao gồm:
  1. Tổng quan về lộ trình.
  2. Danh sách các giai đoạn (milestones), mỗi giai đoạn có các bước nhỏ.
  3. Các tài liệu tham khảo gợi ý.
  4. Một lời khuyên động viên.
  
  Hãy trả về kết quả dưới định dạng Markdown chuyên nghiệp, sử dụng emoji để sinh động.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash",
      contents: prompt
    });
    return response.text || "Không có phản hồi từ AI.";
  } catch (error) {
    console.error("Error generating pathway:", error);
    return "Xin lỗi, đã có lỗi xảy ra khi tạo lộ trình. Vui lòng thử lại sau.";
  }
}
