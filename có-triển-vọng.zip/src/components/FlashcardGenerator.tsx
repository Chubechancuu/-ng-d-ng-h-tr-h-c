import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Library, Loader2, Sparkles, Copy, Check, ChevronLeft, ChevronRight, RotateCw, Search, SortAsc, SortDesc, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { geminiService } from '@/services/geminiService';
import { toast } from 'sonner';

interface Flashcard {
  id: string;
  question: string;
  answer: string;
}

export default function FlashcardGenerator() {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [cards, setCards] = useState<Flashcard[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc' | 'none'>('none');

  const handleGenerate = async () => {
    if (!content.trim()) {
      toast.error('Vui lòng dán nội dung bài học');
      return;
    }
    setLoading(true);
    try {
      const result = await geminiService.generateFlashcards(content);
      
      const lines = result.split('\n').filter(l => l.trim().length > 0);
      const newCards: Flashcard[] = [];
      
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (line.includes('?') || line.toLowerCase().includes('câu hỏi') || line.match(/^\d+\./)) {
          const nextLine = lines[i+1];
          if (nextLine) {
            newCards.push({
              id: Math.random().toString(36).substr(2, 9),
              question: line.replace(/^\d+\.\s*/, '').replace(/Câu hỏi:\s*/i, '').trim(),
              answer: nextLine.replace(/Trả lời:\s*/i, '').replace(/^-\s*/, '').trim()
            });
            i++;
          }
        }
      }

      if (newCards.length === 0) {
        toast.warning('Không thể tạo thẻ tự động, hiển thị nội dung thô');
        setCards([{ id: 'raw', question: 'Nội dung thô', answer: result }]);
      } else {
        setCards(newCards);
        setCurrentIndex(0);
        setIsFlipped(false);
        toast.success(`Đã tạo ${newCards.length} thẻ ghi nhớ!`);
      }
    } catch (error) {
      console.error(error);
      toast.error('Có lỗi xảy ra khi tạo flashcards');
    } finally {
      setLoading(false);
    }
  };

  const filteredAndSortedCards = useMemo(() => {
    let result = [...cards];

    if (searchQuery) {
      result = result.filter(card => 
        card.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
        card.answer.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (sortOrder === 'asc') {
      result.sort((a, b) => a.question.localeCompare(b.question));
    } else if (sortOrder === 'desc') {
      result.sort((a, b) => b.question.localeCompare(a.question));
    }

    return result;
  }, [cards, searchQuery, sortOrder]);

  const nextCard = () => {
    if (currentIndex < filteredAndSortedCards.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setIsFlipped(false);
    }
  };

  const prevCard = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setIsFlipped(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Chuyển đổi kiến thức thành Flashcards</h1>
        <p className="text-slate-500 dark:text-slate-400">Dán nội dung bài học, AI sẽ tự động trích xuất các ý chính thành thẻ ghi nhớ.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1 border-none shadow-md bg-white dark:bg-slate-900">
          <CardContent className="p-6 space-y-4">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-300">
              <Library className="w-4 h-4 text-indigo-500" />
              Nội dung bài học
            </div>
            <Textarea 
              placeholder="Dán văn bản, ghi chú hoặc nội dung bài học vào đây..." 
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-[300px] border-slate-200 dark:border-slate-800 dark:bg-slate-800 dark:text-white focus:ring-indigo-500 resize-none"
            />
            <Button 
              onClick={handleGenerate} 
              disabled={loading}
              className="w-full h-12 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-lg shadow-indigo-100 dark:shadow-none"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Đang tạo thẻ...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Tạo thẻ ghi nhớ
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <div className="lg:col-span-2 flex flex-col items-center justify-center gap-6">
          {cards.length > 0 && (
            <div className="w-full max-w-md flex flex-col gap-4 mb-2">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input 
                    placeholder="Tìm kiếm thẻ..." 
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      setCurrentIndex(0);
                    }}
                    className="pl-10 h-10 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-800 rounded-xl text-sm dark:text-white"
                  />
                </div>
                <Button 
                  variant="outline" 
                  size="icon" 
                  onClick={() => {
                    setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
                    setCurrentIndex(0);
                  }}
                  className={`rounded-xl border-slate-200 dark:border-slate-800 h-10 w-10 ${sortOrder !== 'none' ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800' : 'dark:text-slate-400'}`}
                  title="Sắp xếp theo bảng chữ cái"
                >
                  {sortOrder === 'desc' ? <SortDesc className="w-4 h-4" /> : <SortAsc className="w-4 h-4" />}
                </Button>
              </div>
              {searchQuery && (
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium px-1">
                  Tìm thấy {filteredAndSortedCards.length} kết quả phù hợp
                </p>
              )}
            </div>
          )}

          {filteredAndSortedCards.length > 0 ? (
            <>
              <div className="relative w-full max-w-md h-80 perspective-1000">
                <motion.div
                  key={filteredAndSortedCards[currentIndex]?.id}
                  className="w-full h-full relative transition-all duration-500 preserve-3d cursor-pointer"
                  animate={{ rotateY: isFlipped ? 180 : 0 }}
                  onClick={() => setIsFlipped(!isFlipped)}
                >
                  {/* Front */}
                  <div className="absolute inset-0 backface-hidden bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border-2 border-indigo-100 dark:border-indigo-900/50 flex flex-col items-center justify-center p-12 text-center">
                    <span className="absolute top-6 left-6 text-[10px] font-bold text-indigo-400 dark:text-indigo-500 uppercase tracking-widest">Question</span>
                    <p className="text-xl font-bold text-slate-800 dark:text-white leading-relaxed">
                      {filteredAndSortedCards[currentIndex].question}
                    </p>
                    <div className="absolute bottom-6 text-slate-400 dark:text-slate-500 flex items-center gap-2 text-xs">
                      <RotateCw className="w-3 h-3" />
                      Nhấn để xem đáp án
                    </div>
                  </div>

                  {/* Back */}
                  <div className="absolute inset-0 backface-hidden bg-indigo-600 rounded-3xl shadow-2xl flex flex-col items-center justify-center p-12 text-center text-white rotate-y-180">
                    <span className="absolute top-6 left-6 text-[10px] font-bold text-indigo-200 uppercase tracking-widest">Answer</span>
                    <p className="text-lg font-medium leading-relaxed">
                      {filteredAndSortedCards[currentIndex].answer}
                    </p>
                    <div className="absolute bottom-6 text-indigo-200 flex items-center gap-2 text-xs">
                      <RotateCw className="w-3 h-3" />
                      Nhấn để quay lại
                    </div>
                  </div>
                </motion.div>
              </div>

              <div className="flex items-center gap-6">
                <Button 
                  variant="outline" 
                  size="icon" 
                  onClick={prevCard} 
                  disabled={currentIndex === 0}
                  className="rounded-full w-12 h-12 border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-white"
                >
                  <ChevronLeft className="w-6 h-6" />
                </Button>
                <div className="text-sm font-bold text-slate-500 dark:text-slate-400">
                  {currentIndex + 1} / {filteredAndSortedCards.length}
                </div>
                <Button 
                  variant="outline" 
                  size="icon" 
                  onClick={nextCard} 
                  disabled={currentIndex === filteredAndSortedCards.length - 1}
                  className="rounded-full w-12 h-12 border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-white"
                >
                  <ChevronRight className="w-6 h-6" />
                </Button>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center text-slate-300 dark:text-slate-700 gap-4">
              <div className="w-24 h-24 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                <Library className="w-10 h-10 opacity-20" />
              </div>
              <p className="text-sm font-medium">
                {cards.length > 0 ? 'Không tìm thấy thẻ phù hợp' : 'Thẻ ghi nhớ sẽ xuất hiện tại đây'}
              </p>
            </div>
          )}
        </div>
      </div>
      
      <style>{`
        .perspective-1000 { perspective: 1000px; }
        .preserve-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .rotate-y-180 { transform: rotateY(180deg); }
      `}</style>
    </div>
  );
}
