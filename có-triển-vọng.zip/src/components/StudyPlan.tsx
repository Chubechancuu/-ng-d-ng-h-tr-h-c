import { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Loader2, Calendar, Target, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { geminiService } from '@/services/geminiService';
import ReactMarkdown from 'react-markdown';
import { toast } from 'sonner';

export default function StudyPlan() {
  const [goal, setGoal] = useState('');
  const [timeFrame, setTimeFrame] = useState('1 tháng');
  const [style, setStyle] = useState('Học qua ví dụ');
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!goal.trim()) {
      toast.error('Vui lòng nhập mục tiêu học tập');
      return;
    }
    setLoading(true);
    try {
      const result = await geminiService.generateStudyPlan(goal, timeFrame, style);
      setPlan(result);
      toast.success('Đã tạo lộ trình học tập thành công!');
    } catch (error) {
      console.error(error);
      toast.error('Có lỗi xảy ra khi tạo lộ trình');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Thiết kế lộ trình học tập cá nhân hóa</h1>
        <p className="text-slate-500 dark:text-slate-400">AI sẽ giúp bạn xây dựng một kế hoạch học tập chi tiết dựa trên mục tiêu và phong cách của bạn.</p>
      </div>

      <Card className="border-none shadow-md bg-white dark:bg-slate-900 overflow-hidden">
        <CardContent className="p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2 text-slate-700 dark:text-slate-300">
                  <Target className="w-4 h-4 text-indigo-500" />
                  Mục tiêu học tập của bạn
                </label>
                <Input 
                  placeholder="Vd: Tiếng Anh chuyên ngành Kế toán, Lập trình React..." 
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                  className="h-12 border-slate-200 dark:border-slate-800 dark:bg-slate-800 dark:text-white focus:ring-indigo-500"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2 text-slate-700 dark:text-slate-300">
                  <Calendar className="w-4 h-4 text-indigo-500" />
                  Thời gian cam kết
                </label>
                <Select value={timeFrame} onValueChange={setTimeFrame}>
                  <SelectTrigger className="h-12 border-slate-200 dark:border-slate-800 dark:bg-slate-800 dark:text-white">
                    <SelectValue placeholder="Chọn thời gian" />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                    <SelectItem value="1 tuần">1 tuần</SelectItem>
                    <SelectItem value="2 tuần">2 tuần</SelectItem>
                    <SelectItem value="1 tháng">1 tháng</SelectItem>
                    <SelectItem value="3 tháng">3 tháng</SelectItem>
                    <SelectItem value="6 tháng">6 tháng</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2 text-slate-700 dark:text-slate-300">
                  <BookOpen className="w-4 h-4 text-indigo-500" />
                  Phương pháp bạn thích
                </label>
                <Select value={style} onValueChange={setStyle}>
                  <SelectTrigger className="h-12 border-slate-200 dark:border-slate-800 dark:bg-slate-800 dark:text-white">
                    <SelectValue placeholder="Chọn phương pháp" />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                    <SelectItem value="Học qua ví dụ">Học qua ví dụ</SelectItem>
                    <SelectItem value="Học lý thuyết sâu">Học lý thuyết sâu</SelectItem>
                    <SelectItem value="Học qua bài tập thực hành">Học qua bài tập thực hành</SelectItem>
                    <SelectItem value="Học qua video/hình ảnh">Học qua video/hình ảnh</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="pt-8">
                <Button 
                  onClick={handleGenerate} 
                  disabled={loading}
                  className="w-full h-12 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-lg shadow-indigo-200 dark:shadow-none transition-all duration-200"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Đang xây dựng lộ trình...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 mr-2" />
                      Xây dựng lộ trình ngay
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {plan && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-800 p-8"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Lộ trình học tập của bạn</h2>
            <Button variant="outline" size="sm" onClick={() => window.print()} className="text-slate-500 dark:text-slate-400 dark:border-slate-800">
              In lộ trình
            </Button>
          </div>
          <div className="markdown-body prose prose-indigo dark:prose-invert max-w-none">
            <ReactMarkdown>{plan}</ReactMarkdown>
          </div>
        </motion.div>
      )}
    </div>
  );
}
