import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Upload, Image as ImageIcon, Loader2, Sparkles, FileText, AlertCircle, Send, User, Bot } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { geminiService } from '@/services/geminiService';
import ReactMarkdown from 'react-markdown';
import { toast } from 'sonner';

interface Message {
  role: 'user' | 'model';
  content: string;
}

export default function HomeworkSolver() {
  const [image, setImage] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [context, setContext] = useState('Kế toán bậc Đại học');
  const [messages, setMessages] = useState<Message[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isChatting, setIsChatting] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error('Vui lòng tải lên tệp hình ảnh');
        return;
      }
      setMimeType(file.type);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!image) return;
    setLoading(true);
    setAnalysis(null);
    setMessages([]);
    try {
      const base64Data = image.split(',')[1];
      const result = await geminiService.analyzeHomework(base64Data, mimeType, context);
      setAnalysis(result);
      setMessages([{ role: 'model', content: result }]);
      toast.success('Đã phân tích bài tập xong!');
    } catch (error) {
      console.error(error);
      toast.error('Có lỗi xảy ra khi phân tích bài tập');
    } finally {
      setLoading(false);
    }
  };

  const handleChatSend = async () => {
    if (!chatInput.trim() || isChatting) return;
    
    const userMsg = chatInput;
    setChatInput('');
    const newMessages: Message[] = [...messages, { role: 'user', content: userMsg }];
    setMessages(newMessages);
    setIsChatting(true);

    try {
      const history = newMessages.map(m => ({
        role: m.role,
        parts: [{ text: m.content }]
      }));
      
      const response = await geminiService.homeworkChat(history, userMsg);
      setMessages([...newMessages, { role: 'model', content: response }]);
    } catch (error) {
      console.error(error);
      toast.error('Có lỗi xảy ra khi trao đổi với AI');
    } finally {
      setIsChatting(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Phân tích bài tập chuyên sâu</h1>
        <p className="text-slate-500 dark:text-slate-400">Tải ảnh bài tập lên, AI sẽ giúp bạn giải chi tiết và phân tích các lỗi thường gặp.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 dark:text-slate-300">Bối cảnh / Cấp độ học tập</label>
            <Input 
              placeholder="Vd: Kế toán tài chính, Giải tích đại học..." 
              value={context}
              onChange={(e) => setContext(e.target.value)}
              className="rounded-xl border-slate-200 dark:border-slate-800 dark:bg-slate-800 dark:text-white focus:ring-indigo-500"
            />
          </div>

          <Card className="border-2 border-dashed border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer relative group overflow-hidden h-80 flex flex-col items-center justify-center">
            <input 
              type="file" 
              accept="image/*" 
              onChange={handleFileChange}
              className="absolute inset-0 opacity-0 cursor-pointer z-10"
            />
            {image ? (
              <img 
                src={image} 
                alt="Homework" 
                className="w-full h-full object-contain p-4"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="flex flex-col items-center gap-4 text-slate-400 dark:text-slate-500 group-hover:text-indigo-500 transition-colors">
                <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl shadow-sm">
                  <Upload className="w-8 h-8" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-slate-600 dark:text-slate-300">Nhấp để tải lên hoặc kéo thả</p>
                  <p className="text-xs">PNG, JPG, JPEG (Max 5MB)</p>
                </div>
              </div>
            )}
          </Card>

          <Button 
            onClick={handleAnalyze} 
            disabled={!image || loading}
            className="w-full h-14 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl shadow-lg shadow-indigo-100 dark:shadow-none transition-all duration-200"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Đang giải mã đề bài...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2" />
                Phân tích bài giải
              </>
            )}
          </Button>

          <div className="flex items-start gap-3 p-4 bg-amber-50 dark:bg-amber-900/20 rounded-xl border border-amber-100 dark:border-amber-800">
            <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-800 dark:text-amber-200 leading-relaxed">
              <strong>Lưu ý:</strong> AI có thể nhầm lẫn trong một số trường hợp phức tạp. Hãy sử dụng kết quả như một tài liệu tham khảo để đối chiếu với cách giải của bạn.
            </p>
          </div>
        </div>

        <div className="space-y-6 flex flex-col h-full">
          {analysis ? (
            <div className="flex flex-col h-full bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-800 overflow-hidden">
              <div className="flex items-center justify-between px-8 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50">
                <div className="flex items-center gap-3">
                  <FileText className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                  <h2 className="text-xl font-bold text-slate-900 dark:text-white">Thảo luận bài giải</h2>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setAnalysis(null)} className="text-slate-400 dark:text-slate-500 hover:text-red-500">
                  Làm bài mới
                </Button>
              </div>

              <ScrollArea className="flex-1 p-8">
                <div className="space-y-8">
                  {messages.map((msg, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
                    >
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${
                        msg.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                      }`}>
                        {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                      </div>
                      <div className={`flex-1 p-5 rounded-2xl ${
                        msg.role === 'user' 
                          ? 'bg-indigo-600 text-white rounded-tr-none' 
                          : 'bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 rounded-tl-none text-slate-900 dark:text-slate-100'
                      }`}>
                        <div className={`prose prose-sm max-w-none break-words ${msg.role === 'user' ? 'prose-invert' : 'dark:prose-invert prose-slate'}`}>
                          <ReactMarkdown>{msg.content}</ReactMarkdown>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                  {isChatting && (
                    <div className="flex gap-4">
                      <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                        <Loader2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400 animate-spin" />
                      </div>
                      <div className="bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 px-4 py-2 rounded-2xl rounded-tl-none">
                        <span className="text-xs text-slate-400 italic">AI đang trả lời...</span>
                      </div>
                    </div>
                  )}
                  <div ref={scrollRef} />
                </div>
              </ScrollArea>

              <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900">
                <div className="flex gap-2">
                  <Input 
                    placeholder="Hỏi thêm về bài giải này..." 
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleChatSend()}
                    disabled={isChatting}
                    className="rounded-xl border-slate-200 dark:border-slate-800 dark:bg-slate-800 dark:text-white focus:ring-indigo-500"
                  />
                  <Button 
                    onClick={handleChatSend} 
                    disabled={!chatInput.trim() || isChatting}
                    className="bg-indigo-600 hover:bg-indigo-700 rounded-xl px-4"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[32rem] rounded-2xl border-2 border-slate-100 dark:border-slate-800 border-dashed flex flex-col items-center justify-center text-slate-300 dark:text-slate-700 gap-4">
              <ImageIcon className="w-12 h-12 opacity-20" />
              <p className="text-sm font-medium">Kết quả và thảo luận sẽ hiển thị tại đây</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
