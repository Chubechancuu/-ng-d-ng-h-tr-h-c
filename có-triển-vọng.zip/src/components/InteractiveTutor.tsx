import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, User, Bot, Info, Trash2, Loader2, Volume2, Sparkles, MessageSquarePlus, Mic, MicOff, Search, BookOpen, GraduationCap, ChevronDown, History, Save, Plus, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { geminiService } from '@/services/geminiService';
import ReactMarkdown from 'react-markdown';
import { toast } from 'sonner';

interface Message {
  role: 'user' | 'model';
  content: string;
}

interface ChatSession {
  id: string;
  topic: string;
  messages: Message[];
  timestamp: number;
}

const SUGGESTIONS = [
  "Hãy giải thích cho mình như một đứa trẻ 5 tuổi",
  "Cho mình một ví dụ thực tế",
  "Mình vẫn chưa hiểu lắm, bạn có thể dùng ẩn dụ không?",
  "Hãy kiểm tra kiến thức của mình bằng một câu hỏi trắc nghiệm"
];

const POPULAR_TOPICS = [
  "Kế toán tài chính", "Kế toán quản trị", "Kiểm toán", "Thuế", "Phân tích báo cáo tài chính",
  "Quang hợp", "Hệ mặt trời", "Lỗ đen", "Định luật Newton", "Di truyền học", 
  "Biến đổi khí hậu", "Lịch sử Việt Nam", "Thế chiến II", "Cách mạng Pháp", 
  "Văn minh Ai Cập", "Thời kỳ Phục hưng", "Đại số", "Hình học", 
  "Xác suất thống kê", "Giải tích", "Số học", "Văn học dân gian", 
  "Truyện Kiều", "Văn học hiện đại", "Lập trình Python", "Học tiếng Anh", 
  "Kỹ năng giao tiếp", "Quản lý thời gian"
];

export default function InteractiveTutor() {
  const [topic, setTopic] = useState('');
  const [topicSearch, setTopicSearch] = useState('');
  const [showTopicSuggestions, setShowTopicSuggestions] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [dynamicSuggestions, setDynamicSuggestions] = useState<string[]>([]);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(true);
  const [sessionSearch, setSessionSearch] = useState('');
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [chatSearch, setChatSearch] = useState('');
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [summary, setSummary] = useState<string | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [userProfile, setUserProfile] = useState({
    level: 'Mới bắt đầu',
    goal: 'Học lập trình Python'
  });
  const [activeTab, setActiveTab] = useState<'chat' | 'roadmap' | 'homework'>('chat');
  const [roadmap, setRoadmap] = useState<string | null>(null);
  const [isGeneratingRoadmap, setIsGeneratingRoadmap] = useState(false);
  const [homeworkImage, setHomeworkImage] = useState<string | null>(null);
  const [homeworkSolution, setHomeworkSolution] = useState<string | null>(null);
  const [isSolvingHomework, setIsSolvingHomework] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Load profile from localStorage
  useEffect(() => {
    const savedProfile = localStorage.getItem('eduai_tutor_profile');
    if (savedProfile) {
      try {
        setUserProfile(JSON.parse(savedProfile));
      } catch (e) {
        console.error("Failed to parse saved profile", e);
      }
    }
  }, []);

  // Save profile to localStorage
  useEffect(() => {
    localStorage.setItem('eduai_tutor_profile', JSON.stringify(userProfile));
  }, [userProfile]);

  // Load sessions from localStorage on mount
  useEffect(() => {
    const savedSessions = localStorage.getItem('eduai_tutor_sessions');
    if (savedSessions) {
      try {
        setSessions(JSON.parse(savedSessions));
      } catch (e) {
        console.error("Failed to parse saved sessions", e);
      }
    }

    const savedSearchHistory = localStorage.getItem('eduai_tutor_search_history');
    if (savedSearchHistory) {
      try {
        setSearchHistory(JSON.parse(savedSearchHistory));
      } catch (e) {
        console.error("Failed to parse search history", e);
      }
    }
  }, []);

  // Save sessions to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('eduai_tutor_sessions', JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem('eduai_tutor_search_history', JSON.stringify(searchHistory));
  }, [searchHistory]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const startListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast.error("Trình duyệt của bạn không hỗ trợ nhận diện giọng nói");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "vi-VN";
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => {
      setIsListening(true);
      toast.info("Đang lắng nghe...");
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput(transcript);
      setIsListening(false);
    };

    recognition.onerror = (event: any) => {
      console.error(event.error);
      setIsListening(false);
      toast.error("Lỗi nhận diện giọng nói: " + event.error);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  const handleSend = async (text?: string) => {
    const messageToSend = text || input.trim();
    if (!messageToSend) return;
    if (!topic.trim()) {
      toast.error('Vui lòng nhập chủ đề thảo luận');
      return;
    }

    if (!text) setInput('');
    const newMessages: Message[] = [...messages, { role: 'user', content: messageToSend }];
    setMessages(newMessages);
    setLoading(true);

    try {
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.content }]
      }));

      // Enhanced prompt with user profile context
      const contextPrompt = `Học sinh đang ở trình độ: ${userProfile.level}. Mục tiêu học tập: ${userProfile.goal}. 
      Hãy giải thích phù hợp với trình độ này, ngắn gọn, dễ hiểu và kết thúc bằng 1 câu hỏi kiểm tra nhẹ nhàng.
      
      Câu hỏi của học sinh: ${messageToSend}`;

      const response = await geminiService.tutorChat(topic, history, messageToSend, userProfile.level, userProfile.goal);
      const answer = response.answer || response;
      const followUps = response.followUpQuestions || [];
      
      const updatedMessages: Message[] = [...newMessages, { role: 'model', content: answer }];
      setMessages(updatedMessages);
      setDynamicSuggestions(followUps);
      speak(answer);

      // Update or create session
      if (currentSessionId) {
        setSessions(prev => prev.map(s => 
          s.id === currentSessionId 
            ? { ...s, messages: updatedMessages, timestamp: Date.now() }
            : s
        ));
      } else {
        const newId = Date.now().toString();
        const newSession: ChatSession = {
          id: newId,
          topic: topic,
          messages: updatedMessages,
          timestamp: Date.now()
        };
        setSessions(prev => [newSession, ...prev]);
        setCurrentSessionId(newId);
      }
    } catch (error) {
      console.error(error);
      toast.error('Có lỗi xảy ra khi kết nối với gia sư');
    } finally {
      setLoading(false);
    }
  };

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'vi-VN';
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    } else {
      toast.error('Trình duyệt của bạn không hỗ trợ đọc văn bản');
    }
  };

  const clearChat = () => {
    setMessages([]);
    setDynamicSuggestions([]);
    setCurrentSessionId(null);
    window.speechSynthesis.cancel();
    toast.info('Đã bắt đầu phiên thảo luận mới');
  };

  const loadSession = (session: ChatSession) => {
    setTopic(session.topic);
    setMessages(session.messages);
    setCurrentSessionId(session.id);
    setDynamicSuggestions([]);
    setShowHistory(false);
    toast.success(`Đã tải lại chủ đề: ${session.topic}`);
  };

  const handleSummarize = async () => {
    if (messages.length === 0) return;
    setIsSummarizing(true);
    try {
      const result = await geminiService.summarizeChat(messages);
      setSummary(result);
      toast.success('Đã tạo tóm tắt nội dung!');
    } catch (error) {
      console.error(error);
      toast.error('Không thể tạo tóm tắt');
    } finally {
      setIsSummarizing(false);
    }
  };

  const deleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSessions(prev => prev.filter(s => s.id !== id));
    if (currentSessionId === id) {
      clearChat();
    }
    toast.info('Đã xóa phiên thảo luận');
  };

  const clearHistory = () => {
    setSessions([]);
    localStorage.removeItem('eduai_tutor_sessions');
    clearChat();
    setShowClearConfirm(false);
    toast.info('Đã xóa sạch lịch sử học tập');
  };

  const handleGenerateRoadmap = async () => {
    setIsGeneratingRoadmap(true);
    try {
      const result = await geminiService.generateStudyPlan(
        userProfile.goal, 
        "7 ngày", 
        `Phù hợp với trình độ ${userProfile.level}`
      );
      setRoadmap(result);
      toast.success('Đã tạo lộ trình học tập tối ưu!');
    } catch (error) {
      console.error(error);
      toast.error('Không thể tạo lộ trình');
    } finally {
      setIsGeneratingRoadmap(false);
    }
  };

  const handleHomeworkUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setHomeworkImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSolveHomework = async () => {
    if (!homeworkImage) return;
    setIsSolvingHomework(true);
    try {
      const base64Data = homeworkImage.split(',')[1];
      const mimeType = homeworkImage.split(';')[0].split(':')[1];
      const result = await geminiService.analyzeHomework(base64Data, mimeType, `Trình độ học sinh: ${userProfile.level}`);
      setHomeworkSolution(result);
      toast.success('Đã giải xong bài tập!');
    } catch (error) {
      console.error(error);
      toast.error('Không thể giải bài tập');
    } finally {
      setIsSolvingHomework(false);
    }
  };

  const downloadChat = () => {
    if (messages.length === 0) return;
    const content = messages.map(m => `${m.role === 'user' ? 'Bạn' : 'Gia sư'}: ${m.content}`).join('\n\n');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `thao-luan-${topic || 'gia-su'}-${new Date().toLocaleDateString()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Đã tải xuống nội dung thảo luận');
  };

  const filteredSessions = sessions.filter(s => 
    s.topic.toLowerCase().includes(sessionSearch.toLowerCase()) ||
    s.messages.some(m => m.content.toLowerCase().includes(sessionSearch.toLowerCase()))
  );

  const addToSearchHistory = (query: string) => {
    if (!query.trim()) return;
    setSearchHistory(prev => {
      const filtered = prev.filter(h => h !== query);
      return [query, ...filtered].slice(0, 5);
    });
  };

  const clearSearchHistory = () => {
    setSearchHistory([]);
    localStorage.removeItem('eduai_tutor_search_history');
  };

  return (
    <div className="flex h-[calc(100vh-4rem)] relative overflow-hidden bg-slate-50 dark:bg-slate-950">
      {/* Atmospheric Background Elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-indigo-100/50 dark:bg-indigo-900/20 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-blue-100/50 dark:bg-blue-900/20 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '2s' }} />
        <div className="absolute top-[40%] left-[30%] w-[30%] h-[30%] bg-amber-100/30 dark:bg-amber-900/10 rounded-full blur-[100px]" />
      </div>

      {/* Sidebar for History */}
      <AnimatePresence>
        {showHistory && (
          <motion.aside
            initial={{ x: -300, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -300, opacity: 0 }}
            className="absolute md:relative z-40 w-80 h-full bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl border-r border-slate-200 dark:border-slate-800 shadow-xl flex flex-col"
          >
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 space-y-8">
              <div className="flex items-center justify-between">
                <h2 className="font-bold text-slate-900 dark:text-white flex items-center gap-3 tracking-tight">
                  <div className="p-2 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl">
                    <GraduationCap className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  </div>
                  Hồ Sơ Học Viên
                </h2>
                <Button variant="ghost" size="icon" onClick={() => setShowHistory(false)} className="md:hidden text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
                  <ChevronDown className="w-4 h-4 rotate-90" />
                </Button>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">Trình độ của bạn</label>
                  <select 
                    value={userProfile.level}
                    onChange={(e) => setUserProfile(prev => ({ ...prev, level: e.target.value }))}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl px-4 py-3 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all hover:bg-white dark:hover:bg-slate-700"
                  >
                    <option value="Mới bắt đầu">Mới bắt đầu</option>
                    <option value="Trung bình">Trung bình</option>
                    <option value="Nâng cao">Nâng cao</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">Mục tiêu học tập</label>
                  <Input 
                    value={userProfile.goal}
                    onChange={(e) => setUserProfile(prev => ({ ...prev, goal: e.target.value }))}
                    placeholder="VD: Học lập trình Python..."
                    className="bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 rounded-2xl text-xs text-slate-900 dark:text-white h-11 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">Công Cụ Học Tập</label>
                <div className="grid grid-cols-1 gap-2">
                  <Button 
                    variant={activeTab === 'chat' ? 'default' : 'ghost'} 
                    onClick={() => setActiveTab('chat')}
                    className={`justify-start gap-4 h-12 rounded-2xl text-xs font-bold transition-all ${activeTab === 'chat' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
                  >
                    <MessageSquarePlus className="w-4 h-4" /> Giảng Bài
                  </Button>
                  <Button 
                    variant={activeTab === 'roadmap' ? 'default' : 'ghost'} 
                    onClick={() => setActiveTab('roadmap')}
                    className={`justify-start gap-4 h-12 rounded-2xl text-xs font-bold transition-all ${activeTab === 'roadmap' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
                  >
                    <BookOpen className="w-4 h-4" /> Lộ Trình
                  </Button>
                  <Button 
                    variant={activeTab === 'homework' ? 'default' : 'ghost'} 
                    onClick={() => setActiveTab('homework')}
                    className={`justify-start gap-4 h-12 rounded-2xl text-xs font-bold transition-all ${activeTab === 'homework' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
                  >
                    <GraduationCap className="w-4 h-4" /> Giải Bài Tập
                  </Button>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] px-1">Lịch sử học tập</h3>
                </div>
                <div className="relative group">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400 dark:text-slate-500 group-focus-within:text-indigo-500 transition-colors" />
                  <Input 
                    placeholder="Tìm lại nội dung..." 
                    value={sessionSearch}
                    onChange={(e) => setSessionSearch(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && addToSearchHistory(sessionSearch)}
                    className="pl-9 h-10 bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:ring-indigo-500/20"
                  />
                </div>
              </div>
            </div>
            <ScrollArea className="flex-1 p-4 custom-scrollbar">
              <div className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full h-12 justify-start gap-3 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 hover:border-indigo-200 dark:hover:border-indigo-800 rounded-2xl transition-all group"
                  onClick={clearChat}
                >
                  <div className="p-1.5 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg group-hover:bg-indigo-100 dark:group-hover:bg-indigo-900/40 transition-colors">
                    <Plus className="w-4 h-4" />
                  </div>
                  <span className="font-semibold">Phiên thảo luận mới</span>
                </Button>

                {sessions.length > 0 && (
                  <div className="px-1">
                    {showClearConfirm ? (
                      <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-2xl border border-red-100 dark:border-red-900/30 space-y-3">
                        <p className="text-[11px] text-red-600 dark:text-red-400 font-bold text-center">Xác nhận xóa toàn bộ lịch sử?</p>
                        <div className="flex gap-2">
                          <Button size="sm" variant="destructive" onClick={clearHistory} className="flex-1 h-8 text-[10px] rounded-xl">Xóa hết</Button>
                          <Button size="sm" variant="outline" onClick={() => setShowClearConfirm(false)} className="flex-1 h-8 text-[10px] rounded-xl border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400">Hủy</Button>
                        </div>
                      </div>
                    ) : (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="w-full justify-start gap-2 text-slate-400 dark:text-slate-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-colors"
                        onClick={() => setShowClearConfirm(true)}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span className="text-[10px] font-bold uppercase tracking-wider">Xóa sạch lịch sử</span>
                      </Button>
                    )}
                  </div>
                )}

                {filteredSessions.length === 0 ? (
                  <div className="text-center py-12 px-4">
                    <div className="w-12 h-12 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Search className="w-5 h-5 text-slate-300 dark:text-slate-600" />
                    </div>
                    <p className="text-xs text-slate-400 dark:text-slate-500 font-medium">Không tìm thấy nội dung phù hợp.</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredSessions.map(s => (
                      <motion.div
                        key={s.id}
                        whileHover={{ x: 4 }}
                        onClick={() => loadSession(s)}
                        className={`group relative p-4 rounded-2xl cursor-pointer transition-all border ${
                          currentSessionId === s.id 
                            ? 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-100 dark:border-indigo-900/30 shadow-sm' 
                            : 'hover:bg-slate-50 dark:hover:bg-slate-800 border-transparent'
                        }`}
                      >
                        <div className="flex flex-col gap-1.5 pr-8">
                          <span className={`text-sm font-bold truncate ${currentSessionId === s.id ? 'text-indigo-900 dark:text-indigo-300' : 'text-slate-700 dark:text-slate-300 group-hover:text-slate-900 dark:group-hover:text-white'}`}>
                            {s.topic}
                          </span>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">
                              {new Date(s.timestamp).toLocaleDateString('vi-VN')}
                            </span>
                            <span className="w-1 h-1 bg-slate-200 dark:bg-slate-700 rounded-full" />
                            <span className="text-[10px] text-indigo-500 dark:text-indigo-400 font-bold uppercase tracking-tighter">
                              {s.messages.length} tin nhắn
                            </span>
                          </div>
                        </div>
                        <button 
                          onClick={(e) => deleteSession(s.id, e)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 p-2 text-slate-300 dark:text-slate-600 hover:text-red-500 dark:hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            </ScrollArea>
          </motion.aside>
        )}
      </AnimatePresence>

      <div className="flex-1 flex flex-col relative overflow-hidden z-10">
        {/* Header / Topic Selection */}
        <header className="relative z-30 px-8 py-5 flex items-center justify-between border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl">
          <div className="flex items-center gap-6">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setShowHistory(!showHistory)}
              className={`rounded-2xl h-11 w-11 transition-all ${showHistory ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-400 dark:text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'}`}
            >
              <History className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-indigo-500 to-blue-600 p-3 rounded-2xl shadow-xl shadow-indigo-500/20 rotate-3 group-hover:rotate-0 transition-transform">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-3 tracking-tight">
                  {activeTab === 'chat' ? 'Gia sư AI' : activeTab === 'roadmap' ? 'Lộ trình học tập' : 'Giải bài tập AI'}
                  <Badge className="text-[9px] font-black py-0.5 h-5 border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/30 uppercase tracking-widest">
                    {activeTab === 'chat' ? 'Socratic' : activeTab === 'roadmap' ? 'Personalized' : 'Vision AI'}
                  </Badge>
                </h1>
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-400 dark:text-slate-500 font-medium">
                    {activeTab === 'chat' ? 'Chủ đề hiện tại:' : activeTab === 'roadmap' ? 'Mục tiêu:' : 'Trình độ:'}
                  </span>
                  <button 
                    onClick={() => activeTab === 'chat' && setShowTopicSuggestions(!showTopicSuggestions)}
                    className={`font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5 transition-colors group ${activeTab === 'chat' ? 'hover:text-indigo-500 dark:hover:text-indigo-300' : 'cursor-default'}`}
                  >
                    {activeTab === 'chat' ? (topic || 'Chưa chọn') : activeTab === 'roadmap' ? userProfile.goal : userProfile.level}
                    {activeTab === 'chat' && <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-300 ${showTopicSuggestions ? 'rotate-180' : ''}`} />}
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={clearChat} className="text-slate-400 dark:text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-2xl gap-2 px-4 h-11 font-bold text-xs uppercase tracking-wider">
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Phiên mới</span>
            </Button>
          </div>
        </header>

        {/* Study Toolbar */}
        <div className="relative z-20 px-8 py-3 bg-white/50 dark:bg-slate-900/50 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-6 backdrop-blur-md">
          <div className="relative flex-1 max-w-lg group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-slate-500 group-focus-within:text-indigo-500 transition-colors" />
            <Input 
              placeholder="Tìm kiếm nội dung trong cuộc hội thoại..." 
              value={chatSearch}
              onChange={(e) => setChatSearch(e.target.value)}
              className="pl-11 h-11 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 rounded-2xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:ring-indigo-500/20 transition-all"
            />
          </div>
          
          <div className="flex items-center gap-3 ml-auto">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleSummarize}
              disabled={messages.length === 0 || isSummarizing}
              className="rounded-2xl gap-2 border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 h-11 px-5 font-bold text-xs uppercase tracking-wider transition-all"
            >
              {isSummarizing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              Tóm tắt AI
            </Button>
            
            {messages.length > 0 && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={downloadChat} 
                className="rounded-2xl gap-2 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white h-11 px-5 font-bold text-xs uppercase tracking-wider transition-all"
              >
                <Save className="w-4 h-4" />
                Lưu nội dung
              </Button>
            )}
          </div>
        </div>

        {/* Floating Topic Search */}
        <AnimatePresence>
          {showTopicSuggestions && (
            <motion.div 
              initial={{ opacity: 0, y: -10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              className="absolute top-full left-6 right-6 mt-2 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 z-50 overflow-hidden max-w-2xl"
            >
              <div className="p-4 space-y-4">
                <div className="relative group">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-slate-500 group-focus-within:text-indigo-500 transition-colors" />
                  <Input 
                    placeholder="Tìm kiếm chủ đề mới..." 
                    value={topicSearch}
                    onChange={(e) => setTopicSearch(e.target.value)}
                    className="pl-10 h-11 bg-slate-50 dark:bg-slate-800 border-none rounded-xl focus:ring-2 focus:ring-indigo-500/20 text-slate-900 dark:text-white"
                  />
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-64 overflow-y-auto pr-2 custom-scrollbar">
                  {POPULAR_TOPICS.filter(t => t.toLowerCase().includes(topicSearch.toLowerCase())).map((t) => (
                    <button
                      key={t}
                      onClick={() => {
                        setTopic(t);
                        setShowTopicSuggestions(false);
                        toast.success(`Đã chọn chủ đề: ${t}`);
                      }}
                      className={`text-left px-3 py-2 rounded-xl text-sm transition-all ${
                        topic === t 
                          ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200' 
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 hover:text-indigo-700 dark:hover:text-indigo-400'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Content Area */}
        {activeTab === 'chat' ? (
          <>
            {/* Chat Area */}
            <ScrollArea className="flex-1 custom-scrollbar">
              <div className="max-w-[1000px] mx-auto px-8 py-16 space-y-12">
                {activeTab === 'chat' && (
              <div className="flex items-center gap-3 px-4 py-2 bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-900/30 rounded-2xl w-fit mx-auto mb-8">
                <Info className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <p className="text-xs font-bold text-indigo-700 dark:text-indigo-400">Đang dạy theo trình độ: <span className="text-indigo-900 dark:text-indigo-300">{userProfile.level}</span></p>
              </div>
            )}

            {summary && (
                  <motion.div 
                    initial={{ opacity: 0, y: -20, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    className="p-10 bg-gradient-to-br from-indigo-600 to-blue-700 rounded-[3rem] text-white shadow-2xl relative overflow-hidden group border border-white/10"
                  >
                    <div className="absolute top-0 right-0 p-6">
                      <Button variant="ghost" size="icon" onClick={() => setSummary(null)} className="text-white/40 hover:text-white hover:bg-white/10 rounded-full">
                        <X className="w-5 h-5" />
                      </Button>
                    </div>
                    <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-white/10 rounded-full blur-3xl group-hover:bg-white/20 transition-colors" />
                    
                    <div className="flex items-center gap-4 mb-8">
                      <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-md">
                        <Sparkles className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-black tracking-tight">Tóm tắt tri thức</h3>
                        <p className="text-white/60 text-xs font-bold uppercase tracking-widest">AI Generated Summary</p>
                      </div>
                    </div>
                    <div className="prose prose-invert max-w-none prose-p:leading-relaxed prose-headings:font-black">
                      <ReactMarkdown>{summary}</ReactMarkdown>
                    </div>
                  </motion.div>
                )}

                {messages.length === 0 && (
                  <div className="flex flex-col items-center justify-center min-h-[50vh] text-center space-y-10">
                    <motion.div 
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ type: 'spring', damping: 15 }}
                      className="relative"
                    >
                      <div className="absolute -inset-12 bg-indigo-100 dark:bg-indigo-900/20 rounded-full blur-[80px] animate-pulse" />
                      <div className="w-32 h-32 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-[3rem] flex items-center justify-center shadow-2xl relative rotate-3 hover:rotate-0 transition-transform duration-500">
                        <Bot className="w-16 h-16 text-white" />
                      </div>
                    </motion.div>
                    <div className="max-w-md space-y-4">
                      <h3 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">Khám phá tri thức mới</h3>
                      <p className="text-slate-500 dark:text-slate-400 leading-relaxed font-medium">
                        Chọn một chủ đề bên dưới hoặc nhập câu hỏi của bạn để bắt đầu hành trình khám phá cùng Gia sư AI.
                      </p>
                    </div>
                    <div className="flex flex-wrap justify-center gap-3">
                      {["Kế toán tài chính là gì?", "Phân tích bảng cân đối kế toán", "Định khoản nợ/có"].map((s) => (
                        <Button 
                          key={s} 
                          variant="outline" 
                          onClick={() => { setTopic(s); toast.success(`Đã chọn: ${s}`); }}
                          className="rounded-2xl border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-indigo-600 hover:text-white hover:border-indigo-600 transition-all px-6 h-11 font-bold text-xs"
                        >
                          {s}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
                
                {messages.map((msg, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`flex gap-6 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                      <div className={`flex-shrink-0 mt-2`}>
                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-2xl transition-transform hover:scale-110 ${
                          msg.role === 'user' 
                            ? 'bg-gradient-to-br from-indigo-500 to-blue-600 text-white' 
                            : 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 border border-slate-100 dark:border-slate-800'
                        }`}>
                          {msg.role === 'user' ? <User className="w-6 h-6" /> : <Bot className="w-6 h-6" />}
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div className={`p-8 rounded-[2.5rem] shadow-2xl relative group transition-all ${
                          msg.role === 'user' 
                            ? 'bg-gradient-to-br from-indigo-600 to-blue-700 text-white rounded-tr-none shadow-indigo-500/20' 
                            : 'bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-tl-none text-slate-900 dark:text-white shadow-slate-200/20 dark:shadow-none'
                        } ${chatSearch && msg.content.toLowerCase().includes(chatSearch.toLowerCase()) ? 'ring-4 ring-amber-400 ring-offset-4 ring-offset-[#0a0a0f]' : ''}`}>
                          <div className={`prose prose-lg max-w-none break-words ${msg.role === 'user' ? 'prose-invert font-sans font-medium' : 'prose-slate dark:prose-invert font-serif'}`}>
                            <ReactMarkdown>{msg.content}</ReactMarkdown>
                          </div>
                          
                          {msg.role === 'model' && (
                            <div className="absolute -right-14 top-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => speak(msg.content)}
                                className="h-10 w-10 rounded-full bg-white dark:bg-slate-800 shadow-xl border border-slate-100 dark:border-slate-700 text-slate-400 hover:text-indigo-600 hover:scale-110 transition-all"
                              >
                                <Volume2 className={`w-5 h-5 ${isSpeaking ? 'animate-pulse text-indigo-600' : ''}`} />
                              </Button>
                            </div>
                          )}
                        </div>
                        <div className={`flex items-center gap-3 px-4 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                          <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">
                            {msg.role === 'user' ? 'Học viên' : 'Gia sư AI'}
                          </span>
                          <div className="w-1 h-1 bg-slate-200 dark:bg-slate-800 rounded-full" />
                          <span className="text-[10px] font-mono text-slate-300 dark:text-slate-600">
                            {new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
                
                {loading && (
                  <div className="flex gap-6">
                    <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center">
                      <Loader2 className="w-6 h-6 text-indigo-600 animate-spin" />
                    </div>
                    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 px-8 py-5 rounded-[2.5rem] rounded-tl-none flex items-center gap-4 shadow-sm">
                      <div className="flex gap-1.5">
                        <span className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                        <span className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                        <span className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                      <span className="text-xs font-black text-indigo-600 uppercase tracking-widest italic">Đang phân tích...</span>
                    </div>
                  </div>
                )}
                <div ref={scrollRef} />
              </div>
            </ScrollArea>

            {/* Input Area */}
            <div className="relative z-20 px-8 pb-10 pt-6 bg-gradient-to-t from-slate-50 dark:from-slate-950 via-slate-50/90 dark:via-slate-950/90 to-transparent">
              <div className="max-w-[900px] mx-auto space-y-6">
                {/* Suggestions Bar */}
                <div className="flex flex-wrap gap-2.5 justify-center">
                  <AnimatePresence>
                    {topic && messages.length > 0 && (dynamicSuggestions.length > 0 ? dynamicSuggestions : SUGGESTIONS).map((s, i) => (
                      <motion.button
                        key={i}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        whileHover={{ y: -4, scale: 1.02 }}
                        onClick={() => handleSend(s)}
                        className="px-5 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-indigo-600 hover:text-white hover:border-indigo-500 transition-all shadow-sm flex items-center gap-2.5 group"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-indigo-500 group-hover:text-white transition-colors" />
                        {s}
                      </motion.button>
                    ))}
                  </AnimatePresence>
                </div>

                <div className="relative bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-xl border border-slate-200 dark:border-slate-800 p-3 flex items-end gap-3 focus-within:ring-4 focus-within:ring-indigo-500/10 transition-all group">
                  <Button 
                    type="button"
                    onClick={startListening}
                    variant="ghost"
                    size="icon"
                    className={`h-14 w-14 rounded-[1.5rem] flex-shrink-0 transition-all ${
                      isListening ? 'bg-red-500 text-white animate-pulse' : 'text-slate-400 dark:text-slate-500 hover:text-indigo-600 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    {isListening ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                  </Button>
                  
                  <Textarea 
                    placeholder={topic ? "Nhập câu hỏi của bạn tại đây..." : "Hãy chọn một chủ đề để bắt đầu thảo luận..."}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSend();
                      }
                    }}
                    disabled={loading || !topic}
                    className="flex-1 bg-transparent border-none focus:ring-0 min-h-[64px] max-h-[200px] py-5 px-3 text-lg text-slate-900 dark:text-white placeholder:text-slate-300 dark:placeholder:text-slate-600 resize-none custom-scrollbar font-medium"
                  />

                  <Button 
                    onClick={() => handleSend()}
                    disabled={loading || !input.trim() || !topic}
                    className="h-14 w-14 rounded-[1.5rem] bg-gradient-to-br from-indigo-500 to-blue-600 hover:from-indigo-600 hover:to-blue-700 text-white shadow-lg shadow-indigo-500/20 transition-all active:scale-95 flex-shrink-0 group"
                  >
                    {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Send className="w-6 h-6 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />}
                  </Button>
                </div>
                
                <div className="flex items-center justify-center gap-6">
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 font-black uppercase tracking-[0.3em]">
                    Shift + Enter để xuống dòng
                  </p>
                  <div className="w-1 h-1 bg-slate-200 dark:bg-slate-800 rounded-full" />
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 font-black uppercase tracking-[0.3em]">
                    Voice Input Enabled
                  </p>
                </div>
              </div>
            </div>
          </>
        ) : activeTab === 'roadmap' ? (
          <ScrollArea className="flex-1 custom-scrollbar">
            <div className="max-w-[1000px] mx-auto px-8 py-16 space-y-12">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center space-y-6"
              >
                <div className="w-20 h-20 bg-indigo-100 dark:bg-indigo-900/20 rounded-3xl flex items-center justify-center mx-auto shadow-xl shadow-indigo-500/5">
                  <BookOpen className="w-10 h-10 text-indigo-600 dark:text-indigo-400" />
                </div>
                <div className="space-y-2">
                  <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Lộ trình học tập cá nhân</h2>
                  <p className="text-slate-500 dark:text-slate-400 font-medium">AI sẽ thiết kế lộ trình 7 ngày tối ưu dựa trên mục tiêu của bạn.</p>
                </div>
                
                <div className="max-w-md mx-auto p-8 bg-white dark:bg-slate-900 backdrop-blur-xl border border-slate-200 dark:border-slate-800 rounded-[2.5rem] shadow-xl space-y-6">
                  <div className="space-y-2 text-left">
                    <label className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest ml-1">Mục tiêu của bạn</label>
                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 text-slate-900 dark:text-white font-bold">
                      {userProfile.goal}
                    </div>
                  </div>
                  <div className="space-y-2 text-left">
                    <label className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest ml-1">Trình độ hiện tại</label>
                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 text-slate-900 dark:text-white font-bold">
                      {userProfile.level}
                    </div>
                  </div>
                  
                  <Button 
                    onClick={handleGenerateRoadmap}
                    disabled={isGeneratingRoadmap}
                    className="w-full h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-blue-600 hover:from-indigo-600 hover:to-blue-700 text-white font-black uppercase tracking-widest shadow-2xl shadow-indigo-500/20 transition-all active:scale-95"
                  >
                    {isGeneratingRoadmap ? <Loader2 className="w-6 h-6 animate-spin" /> : "Tạo lộ trình tối ưu"}
                  </Button>
                </div>
              </motion.div>

              {roadmap && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-10 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[3rem] shadow-2xl shadow-slate-200/20 dark:shadow-none"
                >
                  <div className="prose prose-lg max-w-none prose-slate dark:prose-invert font-serif">
                    <ReactMarkdown>{roadmap}</ReactMarkdown>
                  </div>
                </motion.div>
              )}
            </div>
          </ScrollArea>
        ) : (
          <ScrollArea className="flex-1 custom-scrollbar">
            <div className="max-w-[1000px] mx-auto px-8 py-16 space-y-12">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center space-y-6"
              >
                <div className="w-20 h-20 bg-amber-100 dark:bg-amber-900/20 rounded-3xl flex items-center justify-center mx-auto shadow-xl shadow-amber-500/5">
                  <GraduationCap className="w-10 h-10 text-amber-600 dark:text-amber-400" />
                </div>
                <div className="space-y-2">
                  <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Giải bài tập thông minh</h2>
                  <p className="text-slate-500 dark:text-slate-400 font-medium">Chụp ảnh đề bài và nhận lời giải chi tiết từ chuyên gia AI.</p>
                </div>
                
                <div className="max-w-md mx-auto p-8 bg-white dark:bg-slate-900 backdrop-blur-xl border border-slate-200 dark:border-slate-800 rounded-[2.5rem] shadow-xl space-y-8">
                  <div className="relative group">
                    <input 
                      type="file" 
                      accept="image/*"
                      onChange={handleHomeworkUpload}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    <div className="p-10 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-3xl flex flex-col items-center gap-4 group-hover:border-indigo-500 dark:group-hover:border-indigo-400 group-hover:bg-indigo-50 dark:group-hover:bg-indigo-900/20 transition-all">
                      {homeworkImage ? (
                        <img src={homeworkImage} alt="Homework" className="max-h-48 rounded-xl shadow-xl" />
                      ) : (
                        <>
                          <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl">
                            <Plus className="w-8 h-8 text-slate-300 dark:text-slate-600" />
                          </div>
                          <p className="text-sm font-bold text-slate-400 dark:text-slate-500">Tải ảnh đề bài lên</p>
                        </>
                      )}
                    </div>
                  </div>

                  <Button 
                    onClick={handleSolveHomework}
                    disabled={!homeworkImage || isSolvingHomework}
                    className="w-full h-14 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-black uppercase tracking-widest shadow-lg shadow-amber-500/20 transition-all active:scale-95"
                  >
                    {isSolvingHomework ? <Loader2 className="w-6 h-6 animate-spin" /> : "Giải mã đề bài"}
                  </Button>
                </div>
              </motion.div>

              {homeworkSolution && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-10 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[3rem] shadow-2xl shadow-slate-200/20 dark:shadow-none"
                >
                  <div className="flex items-center gap-4 mb-8">
                    <div className="p-3 bg-amber-500/10 dark:bg-amber-900/20 rounded-2xl">
                      <Sparkles className="w-6 h-6 text-amber-600 dark:text-amber-400" />
                    </div>
                    <h3 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Lời giải từ Gia sư</h3>
                  </div>
                  <div className="prose prose-lg max-w-none prose-slate dark:prose-invert font-serif">
                    <ReactMarkdown>{homeworkSolution}</ReactMarkdown>
                  </div>
                </motion.div>
              )}
            </div>
          </ScrollArea>
        )}
      </div>
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #cbd5e1;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #94a3b8;
        }
        .perspective-1000 { perspective: 1000px; }
        .preserve-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .rotate-y-180 { transform: rotateY(180deg); }
      `}</style>
    </div>
  );
}
