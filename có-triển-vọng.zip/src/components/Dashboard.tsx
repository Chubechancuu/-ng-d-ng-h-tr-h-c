import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Lightbulb, 
  Save, 
  Loader2, 
  MessageSquare, 
  Trash2,
  Clock,
  BookOpen,
  Zap,
  Mic,
  MicOff,
  FileUp,
  FileText,
  Layers,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { geminiService } from '@/services/geminiService';
import { toast } from 'sonner';
import ReactMarkdown from 'react-markdown';

interface Note {
  id: string;
  content: string;
  timestamp: number;
}

export default function Dashboard() {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  
  const [noteInput, setNoteInput] = useState('');
  const [notes, setNotes] = useState<Note[]>([]);
  const [isListening, setIsListening] = useState(false);

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const [fileResult, setFileResult] = useState<string | null>(null);
  const [fileTask, setFileTask] = useState<'summary' | 'flashcards'>('summary');

  // Load notes from localStorage
  useEffect(() => {
    const savedNotes = localStorage.getItem('eduai_notes');
    if (savedNotes) {
      setNotes(JSON.parse(savedNotes));
    }
  }, []);

  const startListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast.error("Trình duyệt của bạn không hỗ trợ nhận diện giọng nói");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "vi-VN";
    recognition.onstart = () => setIsListening(true);
    recognition.onresult = (event: any) => {
      setQuestion(event.results[0][0].transcript);
      setIsListening(false);
    };
    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);
    recognition.start();
  };

  const handleAskAI = async () => {
    if (!question.trim()) return;
    setIsTyping(true);
    setAnswer(null);
    try {
      const result = await geminiService.askAI(question);
      setAnswer(result);
    } catch (error) {
      console.error(error);
      toast.error('Có lỗi xảy ra khi hỏi AI');
    } finally {
      setIsTyping(false);
    }
  };

  const saveNote = () => {
    if (!noteInput.trim()) return;
    const newNote: Note = {
      id: Date.now().toString(),
      content: noteInput,
      timestamp: Date.now(),
    };
    const updatedNotes = [newNote, ...notes];
    setNotes(updatedNotes);
    localStorage.setItem('eduai_notes', JSON.stringify(updatedNotes));
    setNoteInput('');
    toast.success('Đã lưu ghi chú!');
  };

  const deleteNote = (id: string) => {
    const updatedNotes = notes.filter(n => n.id !== id);
    setNotes(updatedNotes);
    localStorage.setItem('eduai_notes', JSON.stringify(updatedNotes));
    toast.info('Đã xóa ghi chú');
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 10 * 1024 * 1024) {
        toast.error("Tài liệu quá lớn (tối đa 10MB)");
        return;
      }
      setSelectedFile(file);
      setFileResult(null);
    }
  };

  const processFile = async () => {
    if (!selectedFile) return;
    setIsProcessingFile(true);
    try {
      const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = reject;
        reader.readAsDataURL(selectedFile);
      });
      
      const result = await geminiService.processStudyMaterial(base64Data, selectedFile.type, fileTask);
      setFileResult(result);
      toast.success('Xử lý tài liệu thành công!');
    } catch (error) {
      console.error(error);
      toast.error('Có lỗi xảy ra khi xử lý tài liệu');
    } finally {
      setIsProcessingFile(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Tổng quan học tập</h1>
        <p className="text-slate-500 dark:text-slate-400">Chào mừng bạn quay trở lại! Hôm nay bạn muốn bắt đầu từ đâu?</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cột trái: Hỏi nhanh & Mẹo */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="border-none shadow-xl bg-white dark:bg-slate-900 overflow-hidden">
            <CardHeader className="bg-indigo-600 text-white">
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" /> Hỏi nhanh AI
              </CardTitle>
              <CardDescription className="text-indigo-100">Giải đáp thắc mắc ngay lập tức</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div className="flex gap-2 relative">
                <Input 
                  placeholder="Bạn thắc mắc điều gì? (Vd: Nguyên tắc kế toán dồn tích là gì?)" 
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAskAI()}
                  className="h-12 border-slate-200 dark:border-slate-800 dark:bg-slate-800 dark:text-white focus:ring-indigo-500 pr-12"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={startListening}
                  className={`absolute right-[80px] top-1/2 -translate-y-1/2 h-8 w-8 ${isListening ? 'text-red-500 animate-pulse' : 'text-slate-400'}`}
                >
                  {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </Button>
                <Button 
                  onClick={handleAskAI} 
                  className="h-12 px-6 bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-100 dark:shadow-none"
                  disabled={isTyping || !question.trim()}
                >
                  {isTyping ? <Loader2 className="w-5 h-5 animate-spin" /> : "Gửi"}
                </Button>
              </div>
              
              <AnimatePresence>
                {answer && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-5 bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-800 rounded-2xl text-indigo-900 dark:text-indigo-300 text-sm leading-relaxed"
                  >
                    <div className="flex items-start gap-3">
                      <Zap className="w-4 h-4 text-indigo-600 dark:text-indigo-400 mt-1 flex-shrink-0" />
                      <p>{answer}</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>

          <Card className="border-none shadow-xl bg-white dark:bg-slate-900 overflow-hidden">
            <CardHeader className="bg-slate-900 dark:bg-slate-800 text-white">
              <CardTitle className="flex items-center gap-2">
                <FileUp className="w-5 h-5" /> Phân tích tài liệu học tập
              </CardTitle>
              <CardDescription className="text-slate-400">Tải lên PDF hoặc tài liệu để AI tóm tắt hoặc tạo Flashcard</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div 
                    className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center gap-3 transition-all cursor-pointer ${
                      selectedFile ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20' : 'border-slate-200 dark:border-slate-800 hover:border-indigo-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                    onClick={() => document.getElementById('file-upload')?.click()}
                  >
                    <input 
                      id="file-upload"
                      type="file" 
                      className="hidden" 
                      accept=".pdf,.doc,.docx,.txt"
                      onChange={handleFileChange}
                    />
                    {selectedFile ? (
                      <>
                        <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/40 rounded-xl flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                          <FileText className="w-6 h-6" />
                        </div>
                        <div className="text-center">
                          <p className="text-sm font-bold text-slate-900 dark:text-white truncate max-w-[200px]">{selectedFile.name}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 h-7"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedFile(null);
                            setFileResult(null);
                          }}
                        >
                          <X className="w-3 h-3 mr-1" /> Gỡ bỏ
                        </Button>
                      </>
                    ) : (
                      <>
                        <div className="w-12 h-12 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center text-slate-400 dark:text-slate-500">
                          <FileUp className="w-6 h-6" />
                        </div>
                        <div className="text-center">
                          <p className="text-sm font-bold text-slate-900 dark:text-white">Nhấp để tải lên tài liệu</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">Hỗ trợ PDF, DOCX, TXT (Tối đa 10MB)</p>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                <div className="w-full md:w-64 space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Bạn muốn AI làm gì?</label>
                    <div className="grid grid-cols-2 gap-2">
                      <Button 
                        variant={fileTask === 'summary' ? 'default' : 'outline'}
                        className={`h-20 flex-col gap-2 rounded-xl ${fileTask === 'summary' ? 'bg-indigo-600' : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'}`}
                        onClick={() => setFileTask('summary')}
                      >
                        <FileText className="w-5 h-5" />
                        <span className="text-[10px] font-bold">Tóm tắt</span>
                      </Button>
                      <Button 
                        variant={fileTask === 'flashcards' ? 'default' : 'outline'}
                        className={`h-20 flex-col gap-2 rounded-xl ${fileTask === 'flashcards' ? 'bg-indigo-600' : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'}`}
                        onClick={() => setFileTask('flashcards')}
                      >
                        <Layers className="w-5 h-5" />
                        <span className="text-[10px] font-bold">Flashcards</span>
                      </Button>
                    </div>
                  </div>
                  <Button 
                    className="w-full h-12 bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-100 dark:shadow-none rounded-xl"
                    disabled={!selectedFile || isProcessingFile}
                    onClick={processFile}
                  >
                    {isProcessingFile ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Zap className="w-4 h-4 mr-2" />}
                    Bắt đầu xử lý
                  </Button>
                </div>
              </div>

              <AnimatePresence>
                {fileResult && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="border-t border-slate-100 dark:border-slate-800 pt-6"
                  >
                    <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-6 border border-slate-200 dark:border-slate-700">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                          {fileTask === 'summary' ? <FileText className="w-4 h-4 text-indigo-600 dark:text-indigo-400" /> : <Layers className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />}
                          Kết quả phân tích
                        </h3>
                        <Button variant="ghost" size="sm" onClick={() => setFileResult(null)} className="text-slate-400 dark:text-slate-500">
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="prose prose-sm max-w-none prose-indigo dark:prose-invert prose-slate font-medium text-slate-700 dark:text-slate-300">
                        <ReactMarkdown>{fileResult}</ReactMarkdown>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="border-none shadow-lg bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-amber-700 dark:text-amber-400">
                  <Lightbulb className="w-5 h-5" /> Mẹo học tập
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm text-amber-800 dark:text-amber-200">
                  <li className="flex gap-3">
                    <span className="text-lg">⏱️</span>
                    <span><b>Pomodoro:</b> Học 25p, nghỉ 5p để duy trì sự tập trung cao độ.</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-lg">📝</span>
                    <span><b>Active Recall:</b> Tự đặt câu hỏi và trả lời thay vì chỉ đọc đi đọc lại.</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-lg">🔄</span>
                    <span><b>Spaced Repetition:</b> Ôn tập lại kiến thức sau 1, 3, và 7 ngày.</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg bg-gradient-to-br from-indigo-50 to-blue-50 dark:from-indigo-900/20 dark:to-blue-900/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-indigo-700 dark:text-indigo-400">
                  <BookOpen className="w-5 h-5" /> Thống kê nhanh
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-indigo-800 dark:text-indigo-200">Ghi chú đã lưu</span>
                  <span className="font-bold text-indigo-900 dark:text-indigo-100">{notes.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-indigo-800 dark:text-indigo-200">Phiên học hôm nay</span>
                  <span className="font-bold text-indigo-900 dark:text-indigo-100">0</span>
                </div>
                <div className="h-2 bg-indigo-200 dark:bg-indigo-900 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-600 w-1/3"></div>
                </div>
                <p className="text-[10px] text-indigo-500 dark:text-indigo-400 text-center italic">"Hành trình vạn dặm bắt đầu từ một bước chân"</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Cột phải: Ghi chú */}
        <div className="space-y-6">
          <Card className="border-none shadow-xl h-full bg-white dark:bg-slate-900">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-slate-900 dark:text-white">
                <Save className="w-5 h-5 text-emerald-500" /> Sổ tay ghi chú
              </CardTitle>
              <CardDescription className="dark:text-slate-400">Lưu lại những kiến thức quan trọng</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea 
                placeholder="Ghi lại kiến thức mới hoặc ý tưởng của bạn..." 
                className="min-h-[120px] border-slate-200 dark:border-slate-800 dark:bg-slate-800 dark:text-white focus:ring-emerald-500 resize-none"
                value={noteInput}
                onChange={(e) => setNoteInput(e.target.value)}
              />
              <Button 
                onClick={saveNote} 
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-lg shadow-emerald-100 dark:shadow-none"
                disabled={!noteInput.trim()}
              >
                Lưu ghi chú
              </Button>

              <div className="space-y-3 mt-8 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                <AnimatePresence initial={false}>
                  {notes.map((note) => (
                    <motion.div
                      key={note.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className="group p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700 relative hover:bg-white dark:hover:bg-slate-700 hover:shadow-md transition-all duration-200"
                    >
                      <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed pr-6">{note.content}</p>
                      <div className="flex items-center gap-2 mt-3 text-[10px] text-slate-400">
                        <Clock className="w-3 h-3" />
                        {new Date(note.timestamp).toLocaleDateString('vi-VN')} {new Date(note.timestamp).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                      </div>
                      <button 
                        onClick={() => deleteNote(note.id)}
                        className="absolute top-3 right-3 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </motion.div>
                  ))}
                </AnimatePresence>
                {notes.length === 0 && (
                  <div className="text-center py-12 text-slate-300 dark:text-slate-600">
                    <Save className="w-8 h-8 mx-auto mb-2 opacity-20" />
                    <p className="text-xs">Chưa có ghi chú nào</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #e2e8f0;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #cbd5e1;
        }
      `}</style>
    </div>
  );
}
