import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Video, 
  Upload, 
  Sparkles, 
  FileVideo, 
  Loader2, 
  CheckCircle2, 
  AlertCircle,
  Play,
  Download,
  History,
  Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { geminiService } from '@/services/geminiService';
import { toast } from 'sonner';
import ReactMarkdown from 'react-markdown';

export default function VideoLab() {
  const [activeTab, setActiveTab] = useState('generate');
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
  const [generationStatus, setGenerationStatus] = useState('');
  
  const [selectedVideo, setSelectedVideo] = useState<File | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [summary, setSummary] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const REASSURING_MESSAGES = [
    "Đang phân tích ý tưởng của bạn...",
    "Đang phác thảo các khung hình giáo dục...",
    "AI đang vẽ các chi tiết minh họa...",
    "Đang render video chất lượng cao cho bạn...",
    "Sắp xong rồi, video đang được hoàn thiện...",
    "Đang kiểm tra lại độ chính xác của kiến thức..."
  ];

  const handleGenerateVideo = async () => {
    if (!prompt.trim()) {
      toast.error("Vui lòng nhập chủ đề video!");
      return;
    }

    setIsGenerating(true);
    setGeneratedVideoUrl(null);
    let messageIndex = 0;
    setGenerationStatus(REASSURING_MESSAGES[0]);

    const interval = setInterval(() => {
      messageIndex = (messageIndex + 1) % REASSURING_MESSAGES.length;
      setGenerationStatus(REASSURING_MESSAGES[messageIndex]);
    }, 5000);

    try {
      const operation = await geminiService.generateVideo(prompt);
      
      // Polling for completion
      let currentOp = operation;
      while (!currentOp.done) {
        await new Promise(resolve => setTimeout(resolve, 5000));
        currentOp = await geminiService.getVideoOperation(currentOp.name);
      }

      const response = currentOp.response as any;
      if (response?.videos?.[0]?.uri) {
        setGeneratedVideoUrl(response.videos[0].uri);
        toast.success("Video đã được tạo thành công!");
      } else {
        throw new Error("Không tìm thấy video trong phản hồi.");
      }
    } catch (error) {
      console.error(error);
      toast.error("Có lỗi xảy ra khi tạo video. Vui lòng thử lại.");
    } finally {
      clearInterval(interval);
      setIsGenerating(false);
      setGenerationStatus('');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 20 * 1024 * 1024) {
        toast.error("Video quá lớn! Vui lòng chọn file dưới 20MB.");
        return;
      }
      setSelectedVideo(file);
      setSummary(null);
    }
  };

  const handleSummarizeVideo = async () => {
    if (!selectedVideo) {
      toast.error("Vui lòng chọn một video!");
      return;
    }

    setIsSummarizing(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(selectedVideo);
      reader.onload = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        const result = await geminiService.summarizeVideo(base64Data, selectedVideo.type);
        setSummary(result);
        toast.success("Đã hoàn thành tóm tắt video!");
      };
    } catch (error) {
      console.error(error);
      toast.error("Lỗi khi phân tích video.");
    } finally {
      setIsSummarizing(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 p-2 rounded-xl">
            <Video className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Video Lab AI</h1>
          <Badge className="bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 border-none">Experimental</Badge>
        </div>
        <p className="text-slate-500 dark:text-slate-400">Sáng tạo và phân tích nội dung giáo dục thông qua sức mạnh của AI Video.</p>
      </div>

      <Tabs defaultValue="generate" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-1 rounded-xl h-12">
          <TabsTrigger value="generate" className="rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white dark:text-slate-400">
            Tạo Video AI
          </TabsTrigger>
          <TabsTrigger value="summarize" className="rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white dark:text-slate-400">
            Tóm tắt Video
          </TabsTrigger>
        </TabsList>

        <TabsContent value="generate" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="border-none shadow-xl bg-white dark:bg-slate-900 rounded-3xl overflow-hidden">
              <CardHeader className="pb-4">
                <CardTitle className="text-xl flex items-center gap-2 dark:text-white">
                  <Sparkles className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  Ý tưởng Video
                </CardTitle>
                <CardDescription className="dark:text-slate-400">Mô tả chủ đề bạn muốn AI tạo thành video giáo dục.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Chủ đề hoặc khái niệm</label>
                  <Input 
                    placeholder="Vd: Quá trình quang hợp của cây xanh, Cách hoạt động của động cơ phản lực..." 
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="h-14 rounded-2xl border-slate-200 dark:border-slate-800 dark:bg-slate-800 dark:text-white focus:ring-indigo-500"
                  />
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl flex items-start gap-3">
                  <Info className="w-5 h-5 text-slate-400 dark:text-slate-500 mt-0.5" />
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    Video AI sẽ được tạo dựa trên mô tả của bạn. Quá trình này có thể mất vài phút tùy thuộc vào độ phức tạp của yêu cầu.
                  </p>
                </div>

                <Button 
                  onClick={handleGenerateVideo} 
                  disabled={isGenerating || !prompt.trim()}
                  className="w-full h-14 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-lg font-bold shadow-lg shadow-indigo-100 dark:shadow-none transition-all active:scale-95"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Đang tạo video...
                    </>
                  ) : (
                    <>
                      <Video className="w-5 h-5 mr-2" />
                      Bắt đầu tạo Video
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            <Card className="border-none shadow-xl bg-slate-900 text-white rounded-3xl overflow-hidden min-h-[400px] flex flex-col items-center justify-center relative">
              <AnimatePresence mode="wait">
                {isGenerating ? (
                  <motion.div 
                    key="generating"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex flex-col items-center gap-6 p-8 text-center"
                  >
                    <div className="relative">
                      <div className="w-24 h-24 border-4 border-indigo-500/30 rounded-full animate-pulse" />
                      <Loader2 className="w-12 h-12 text-indigo-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-spin" />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-xl font-bold">AI đang làm việc</h3>
                      <p className="text-indigo-300 font-medium animate-pulse">{generationStatus}</p>
                    </div>
                  </motion.div>
                ) : generatedVideoUrl ? (
                  <motion.div 
                    key="result"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="w-full h-full flex flex-col"
                  >
                    <video 
                      src={generatedVideoUrl} 
                      controls 
                      className="w-full h-full object-contain bg-black"
                    />
                    <div className="p-4 bg-slate-800 flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-400" />
                        <span className="text-sm font-medium">Video đã sẵn sàng</span>
                      </div>
                      <Button variant="ghost" size="sm" className="text-white hover:bg-slate-700" onClick={() => window.open(generatedVideoUrl, '_blank')}>
                        <Download className="w-4 h-4 mr-2" />
                        Tải xuống
                      </Button>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div 
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex flex-col items-center gap-4 p-8 text-center opacity-40"
                  >
                    <div className="bg-slate-800 p-6 rounded-full">
                      <Play className="w-12 h-12" />
                    </div>
                    <p className="text-sm max-w-[200px]">Video của bạn sẽ xuất hiện tại đây sau khi được tạo.</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="summarize" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1 space-y-6">
              <Card className="border-none shadow-xl bg-white dark:bg-slate-900 rounded-3xl overflow-hidden">
                <CardHeader>
                  <CardTitle className="text-xl flex items-center gap-2 dark:text-white">
                    <Upload className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                    Tải Video lên
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center gap-4 cursor-pointer transition-all ${
                      selectedVideo ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20' : 'border-slate-200 dark:border-slate-800 hover:border-indigo-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <input 
                      type="file" 
                      ref={fileInputRef} 
                      onChange={handleFileChange} 
                      accept="video/*" 
                      className="hidden" 
                    />
                    {selectedVideo ? (
                      <>
                        <div className="bg-indigo-600 p-3 rounded-xl shadow-lg">
                          <FileVideo className="w-8 h-8 text-white" />
                        </div>
                        <div className="text-center">
                          <p className="text-sm font-bold text-slate-900 dark:text-white truncate max-w-[150px]">{selectedVideo.name}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{(selectedVideo.size / (1024 * 1024)).toFixed(2)} MB</p>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-xl">
                          <Upload className="w-8 h-8 text-slate-400 dark:text-slate-500" />
                        </div>
                        <div className="text-center">
                          <p className="text-sm font-medium text-slate-900 dark:text-slate-300">Nhấn để tải video</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">Hỗ trợ MP4, WebM (Tối đa 20MB)</p>
                        </div>
                      </>
                    )}
                  </div>

                  <Button 
                    onClick={handleSummarizeVideo} 
                    disabled={isSummarizing || !selectedVideo}
                    className="w-full h-14 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-lg font-bold shadow-lg shadow-indigo-100 dark:shadow-none transition-all active:scale-95"
                  >
                    {isSummarizing ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Đang phân tích...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Tóm tắt ngay
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-none shadow-sm bg-indigo-50/50 dark:bg-indigo-900/10 rounded-2xl">
                <CardContent className="p-4 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-indigo-600 dark:text-indigo-400 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-indigo-900 dark:text-indigo-200">Mẹo nhỏ</p>
                    <p className="text-[11px] text-indigo-700 dark:text-indigo-400 leading-relaxed">
                      AI sẽ xem toàn bộ video và trích xuất các ý chính, giúp bạn tiết kiệm thời gian học tập.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-2">
              <Card className="border-none shadow-xl bg-white dark:bg-slate-900 rounded-3xl overflow-hidden h-full min-h-[500px] flex flex-col">
                <CardHeader className="border-b border-slate-50 dark:border-slate-800">
                  <CardTitle className="text-xl flex items-center gap-2 dark:text-white">
                    <History className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                    Kết quả phân tích
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex-1 p-0 overflow-hidden">
                  <AnimatePresence mode="wait">
                    {isSummarizing ? (
                      <motion.div 
                        key="loading"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="h-full flex flex-col items-center justify-center p-12 text-center gap-4"
                      >
                        <Loader2 className="w-12 h-12 text-indigo-600 dark:text-indigo-400 animate-spin" />
                        <div className="space-y-1">
                          <p className="font-bold text-slate-900 dark:text-white">AI đang "xem" video của bạn</p>
                          <p className="text-sm text-slate-500 dark:text-slate-400">Quá trình này có thể mất 30-60 giây...</p>
                        </div>
                      </motion.div>
                    ) : summary ? (
                      <motion.div 
                        key="content"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="h-full overflow-y-auto p-8"
                      >
                        <div className="prose prose-indigo dark:prose-invert max-w-none">
                          <ReactMarkdown>{summary}</ReactMarkdown>
                        </div>
                      </motion.div>
                    ) : (
                      <motion.div 
                        key="empty"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="h-full flex flex-col items-center justify-center p-12 text-center opacity-40 gap-4"
                      >
                        <FileVideo className="w-16 h-16 text-slate-300 dark:text-slate-700" />
                        <p className="text-sm max-w-[250px] dark:text-slate-500">Tải video lên và nhấn tóm tắt để xem kết quả phân tích tại đây.</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
