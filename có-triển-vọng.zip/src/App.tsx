import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  GraduationCap, 
  Search, 
  Library, 
  Timer, 
  ChevronRight,
  BrainCircuit,
  Menu,
  X,
  Video,
  Play,
  Pause,
  RotateCcw,
  Moon,
  Sun
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Toaster, toast } from 'sonner';
import Dashboard from './components/Dashboard';
import StudyPlan from './components/StudyPlan';
import InteractiveTutor from './components/InteractiveTutor';
import HomeworkSolver from './components/HomeworkSolver';
import FlashcardGenerator from './components/FlashcardGenerator';
import VideoLab from './components/VideoLab';

type MenuType = 'dashboard' | 'roadmap' | 'tutor' | 'analysis' | 'flashcards' | 'video';

export default function App() {
  const [activeMenu, setActiveMenu] = useState<MenuType>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [timerMinutes, setTimerMinutes] = useState(25);
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const savedTheme = localStorage.getItem('eduai_theme');
    if (savedTheme === 'dark') {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    if (newMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('eduai_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('eduai_theme', 'light');
    }
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsTimerRunning(false);
      toast.success("Hết giờ! Nghỉ ngơi thôi.", {
        description: "Bạn đã hoàn thành một phiên tập trung.",
      });
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const startTimer = () => {
    setTimeLeft(timerMinutes * 60);
    setIsTimerRunning(true);
  };

  const toggleTimer = () => setIsTimerRunning(!isTimerRunning);
  const resetTimer = () => {
    setIsTimerRunning(false);
    setTimeLeft(timerMinutes * 60);
  };

  const menuItems = [
    { id: 'dashboard', label: 'Tổng quan', icon: LayoutDashboard },
    { id: 'roadmap', label: 'Lộ trình 360', icon: GraduationCap },
    { id: 'tutor', label: 'Gia sư tương tác', icon: BrainCircuit },
    { id: 'analysis', label: 'Giải bài & Phân tích', icon: Search },
    { id: 'flashcards', label: 'Flashcard tự động', icon: Library },
    { id: 'video', label: 'Video Lab AI', icon: Video },
  ];

  return (
    <div className="flex h-screen bg-slate-50 font-sans overflow-hidden">
      <Toaster position="top-right" />
      
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 280 : 80 }}
        className="bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col z-20"
      >
        <div className="p-6 flex items-center justify-between">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="bg-indigo-600 p-2 rounded-xl">
              <BrainCircuit className="w-6 h-6 text-white" />
            </div>
            {isSidebarOpen && (
              <span className="font-bold text-xl tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
                có triển vọng
              </span>
            )}
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="hidden md:flex dark:text-slate-400"
          >
            {isSidebarOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </Button>
        </div>

        <nav className="flex-1 px-3 space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveMenu(item.id as MenuType)}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 ${
                activeMenu === item.id 
                  ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 font-medium' 
                  : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <item.icon className={`w-5 h-5 flex-shrink-0 ${activeMenu === item.id ? 'text-indigo-600' : ''}`} />
              {isSidebarOpen && <span className="whitespace-nowrap">{item.label}</span>}
              {activeMenu === item.id && isSidebarOpen && (
                <ChevronRight className="w-4 h-4 ml-auto" />
              )}
            </button>
          ))}
        </nav>

        {/* Pomodoro Timer in Sidebar */}
        <div className="p-4 mt-auto">
          <Card className={`border-none shadow-sm bg-slate-900 text-white transition-all duration-300 ${!isSidebarOpen ? 'p-0 overflow-hidden' : ''}`}>
            {isSidebarOpen ? (
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center gap-2 text-slate-400 text-xs font-medium uppercase tracking-wider">
                  <Timer className="w-3 h-3" />
                  Focus Timer
                </div>
                <div className="text-3xl font-mono font-bold text-center">
                  {formatTime(timeLeft)}
                </div>
                <div className="flex items-center gap-2">
                  <Input 
                    type="number" 
                    value={timerMinutes} 
                    onChange={(e) => setTimerMinutes(parseInt(e.target.value) || 1)}
                    className="bg-slate-800 border-slate-700 text-white h-8 text-xs"
                    placeholder="Mins"
                  />
                  <Button size="sm" onClick={startTimer} disabled={isTimerRunning} className="bg-indigo-600 hover:bg-indigo-700 h-8 text-xs">
                    Start
                  </Button>
                </div>
                <div className="flex justify-center gap-2">
                  <Button variant="ghost" size="icon" onClick={toggleTimer} className="text-white hover:bg-slate-800">
                    {isTimerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </Button>
                  <Button variant="ghost" size="icon" onClick={resetTimer} className="text-white hover:bg-slate-800">
                    <RotateCcw className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            ) : (
              <div className="flex flex-col items-center py-4 gap-4">
                <Timer className="w-5 h-5 text-indigo-400" />
                <div className="text-[10px] font-mono font-bold rotate-90">
                  {formatTime(timeLeft)}
                </div>
              </div>
            )}
          </Card>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden dark:bg-slate-950">
        <header className="h-16 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center px-8 justify-between">
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 border-indigo-100 dark:border-indigo-800 font-medium">
              AI Powered
            </Badge>
            <h2 className="text-sm font-medium text-slate-500 dark:text-slate-400">
              {menuItems.find(m => m.id === activeMenu)?.label}
            </h2>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleDarkMode}
              className="text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>
            <div className="text-right hidden sm:block">
              <p className="text-xs font-medium text-slate-900 dark:text-white">Gia Hân</p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">Premium Student</p>
            </div>
            <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center text-indigo-700 dark:text-indigo-300 font-bold text-xs border border-indigo-200 dark:border-indigo-800">
              GH
            </div>
          </div>
        </header>

        <div className={`flex-1 overflow-y-auto ${activeMenu === 'tutor' ? 'p-0 md:p-0' : 'p-8'}`}>
          <AnimatePresence mode="wait">
            <motion.div
              key={activeMenu}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className={`${activeMenu === 'tutor' ? 'max-w-none px-2 md:px-6' : 'max-w-5xl'} mx-auto w-full`}
            >
              {activeMenu === 'dashboard' && <Dashboard />}
              {activeMenu === 'roadmap' && <StudyPlan />}
              {activeMenu === 'tutor' && <InteractiveTutor />}
              {activeMenu === 'analysis' && <HomeworkSolver />}
              {activeMenu === 'flashcards' && <FlashcardGenerator />}
              {activeMenu === 'video' && <VideoLab />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
