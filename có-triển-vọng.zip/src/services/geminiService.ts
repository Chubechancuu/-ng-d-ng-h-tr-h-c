import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const geminiService = {
  async generateStudyPlan(goal: string, timeFrame: string, style: string) {
    const prompt = `Đóng vai một chuyên gia giáo dục. Thiết kế lộ trình học cho: ${goal}.
    - Thời gian: ${timeFrame}
    - Phong cách học: ${style}
    Hãy trình bày dưới dạng Markdown chuyên nghiệp, sử dụng bảng nếu cần thiết. Bao gồm: Tuần, Nội dung chính, Tài liệu tham khảo và Bài tập thực hành.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    return response.text;
  },

  async tutorChat(topic: string, history: { role: 'user' | 'model', parts: { text: string }[] }[], message: string, level: string = 'Mới bắt đầu', goal: string = '') {
    const chat = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction: `Bạn là một gia sư AI thông thái, ấm áp và kiên nhẫn. Bạn đang hướng dẫn học sinh về chủ đề: "${topic}".
Trình độ học sinh: ${level}.
Mục tiêu học tập: ${goal}.

Nhiệm vụ của bạn:
1. Áp dụng phương pháp Socratic: Thay vì đưa ra câu trả lời ngay lập tức, hãy đặt những câu hỏi gợi mở, dẫn dắt để học sinh tự suy luận và tìm ra đáp án.
2. Khuyến khích: Luôn bắt đầu bằng việc công nhận nỗ lực hoặc ý tưởng đúng của học sinh.
3. Sử dụng ẩn dụ: Dùng những ví dụ đời thường để minh họa khái niệm khó.
4. Phản hồi sai sót: Dẫn dắt học sinh nhận ra lỗi sai một cách nhẹ nhàng.
5. Cấu trúc: Giữ câu trả lời ngắn gọn, súc tích.
6. Ngôn ngữ: Sử dụng tiếng Việt tự nhiên, gần gũi.
7. Gợi ý mở rộng: Luôn tạo ra 3 câu hỏi gợi ý tiếp theo.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            answer: {
              type: Type.STRING,
              description: "Câu trả lời của gia sư cho học sinh."
            },
            followUpQuestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Danh sách 3 câu hỏi gợi ý tiếp theo."
            }
          },
          required: ["answer", "followUpQuestions"]
        }
      },
      history: history,
    });

    const response = await chat.sendMessage({ message });
    try {
      return JSON.parse(response.text);
    } catch (e) {
      return {
        answer: response.text,
        followUpQuestions: []
      };
    }
  },

  async analyzeHomework(imageBuffer: string, mimeType: string, context?: string) {
    const prompt = `Bạn là một chuyên gia học thuật cấp cao. Hãy giải chi tiết bài tập này.
    ${context ? `Bối cảnh/Yêu cầu bổ sung: ${context}` : ""}
    
    Yêu cầu:
    1. Giải chi tiết từng bước (Step-by-step).
    2. Nếu là bài tập Kế toán/Tài chính: Hãy trình bày rõ các định khoản, bảng cân đối hoặc báo cáo liên quan.
    3. Phân tích các lỗi sai thường gặp và các lưu ý quan trọng cho trình độ Đại học.
    4. Trình bày bằng Markdown chuyên nghiệp, sử dụng bảng biểu nếu cần.`;
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          { text: prompt },
          { inlineData: { data: imageBuffer, mimeType } }
        ]
      }
    });

    return response.text;
  },

  async generateFlashcards(content: string) {
    const prompt = `Từ nội dung sau, hãy tạo 5-10 cặp câu hỏi-trả lời ngắn gọn để học thuộc: ${content}. 
    Trình bày dưới dạng danh sách các thẻ Flashcard rõ ràng.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    return response.text;
  },

  async processStudyMaterial(fileData: string, mimeType: string, task: 'summary' | 'flashcards') {
    const prompt = task === 'summary' 
      ? "Hãy tóm tắt tài liệu này một cách chi tiết, làm nổi bật các kiến thức trọng tâm và các khái niệm quan trọng. Sử dụng Markdown."
      : "Từ tài liệu này, hãy tạo 10 cặp câu hỏi-trả lời Flashcard ngắn gọn để giúp học thuộc kiến thức. Trình bày dưới dạng danh sách rõ ràng.";
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          { text: prompt },
          { inlineData: { data: fileData, mimeType } }
        ]
      }
    });

    return response.text;
  },

  async generateVideo(prompt: string, resolution: '720p' | '1080p' = '1080p') {
    const operation = await ai.models.generateVideos({
      model: 'veo-3.1-lite-generate-preview',
      prompt: `Tạo một video giáo dục ngắn về: ${prompt}. Video nên có phong cách minh họa rõ ràng, dễ hiểu cho học sinh.`,
      config: {
        numberOfVideos: 1,
        resolution: resolution,
        aspectRatio: '16:9'
      }
    });

    // We return the operation so the component can poll it
    return operation;
  },

  async getVideoOperation(operationName: string) {
    return await (ai.operations as any).get(operationName);
  },

  async summarizeVideo(videoData: string, mimeType: string) {
    const prompt = "Hãy xem video này và tóm tắt các nội dung chính một cách chi tiết. Chia thành các mục: Kiến thức trọng tâm, Giải thích các khái niệm khó, và Câu hỏi ôn tập.";
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          { text: prompt },
          { inlineData: { data: videoData, mimeType } }
        ]
      }
    });

    return response.text;
  },

  async askAI(question: string) {
    const prompt = `Bạn là một trợ lý học tập thông minh. Trả lời câu hỏi sau một cách ngắn gọn, súc tích và dễ hiểu: ${question}`;
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    return response.text;
  },

  async homeworkChat(history: { role: 'user' | 'model', parts: { text: string }[] }[], message: string) {
    const chat = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction: `Bạn là một chuyên gia học thuật đang hỗ trợ học sinh giải đáp thắc mắc về bài tập đã được phân tích. 
        Hãy trả lời các câu hỏi tiếp theo của học sinh một cách chi tiết, chính xác và dễ hiểu. 
        Nếu liên quan đến Kế toán, hãy giải thích rõ các nguyên tắc và định khoản.`,
      },
      history: history,
    });

    const response = await chat.sendMessage({ message });
    return response.text;
  },

  async summarizeChat(history: { role: 'user' | 'model', content: string }[]) {
    const prompt = `Hãy tóm tắt nội dung cuộc thảo luận sau đây một cách ngắn gọn, súc tích. 
    Làm nổi bật các kiến thức trọng tâm và những điểm cần lưu ý. 
    Sử dụng Markdown để trình bày.
    
    Nội dung thảo luận:
    ${history.map(m => `${m.role === 'user' ? 'Học sinh' : 'Gia sư'}: ${m.content}`).join('\n')}`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    return response.text;
  }
};
